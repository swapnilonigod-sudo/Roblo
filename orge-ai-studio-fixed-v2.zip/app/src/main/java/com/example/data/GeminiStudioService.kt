package com.example.data

import android.graphics.Bitmap
import android.util.Log
import com.example.model.AiChatMessage
import com.example.model.AiModelChoice
import com.example.model.ForgeMaterial
import com.example.model.ImageAspectOption
import com.example.model.ImageModelChoice
import com.example.model.ImageResolutionOption
import com.example.model.LightingSettings
import com.example.model.NodeKind
import com.example.model.SceneNode
import com.example.model.SceneShape
import com.example.model.TimeOfDay
import com.example.model.Vec3
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.AspectRatio
import com.google.firebase.ai.type.ImageConfig
import com.google.firebase.ai.type.ImagePart
import com.google.firebase.ai.type.ImageSize
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class SceneAiOperation(
    val action: String, // CREATE_FOLDER, CREATE_OBJECT, MODIFY_OBJECT, DELETE_OBJECT, SET_LIGHTING
    val targetName: String? = null,
    val name: String = "Part",
    val folderName: String? = null,
    val kind: NodeKind = NodeKind.PART,
    val shape: SceneShape = SceneShape.BOX,
    val position: Vec3? = null,
    val rotation: Vec3? = null,
    val scale: Vec3? = null,
    val colorHex: String? = null,
    val material: ForgeMaterial? = null,
    val canCollide: Boolean? = null,
    val timeOfDay: TimeOfDay? = null
)

data class SceneAiPlanResult(
    val summary: String,
    val operations: List<SceneAiOperation>
)

data class LuauAiResponse(
    val scriptName: String,
    val scriptType: String,
    val parentTarget: String,
    val explanation: String,
    val code: String
)

class GeminiStudioService {

    companion object {
        private const val TAG = "GeminiStudioService"
        private const val TIMEOUT_MS = 60_000L
    }

    private val sceneActionSchema = Schema.obj(
        properties = mapOf(
            "summary" to Schema.string(description = "Brief 1-2 sentence explanation of what was built or modified in the 3D scene."),
            "operations" to Schema.array(
                description = "Ordered list of validated 3D scene operations to execute.",
                items = Schema.obj(
                    properties = mapOf(
                        "action" to Schema.enumeration(
                            values = listOf("CREATE_FOLDER", "CREATE_OBJECT", "MODIFY_OBJECT", "DELETE_OBJECT", "SET_LIGHTING"),
                            description = "Scene operation type."
                        ),
                        "targetName" to Schema.string(description = "Existing object name or 'SELECTED' for MODIFY_OBJECT or DELETE_OBJECT."),
                        "name" to Schema.string(description = "Name of the folder or 3D object."),
                        "folderName" to Schema.string(description = "Optional parent folder name to organize objects."),
                        "kind" to Schema.enumeration(
                            values = NodeKind.entries.map { it.name },
                            description = "Logical asset category."
                        ),
                        "shape" to Schema.enumeration(
                            values = listOf("BOX", "SPHERE", "CYLINDER", "CONE", "WEDGE", "TORUS", "TERRAIN_PLANE"),
                            description = "3D geometric primitive or terrain patch."
                        ),
                        "px" to Schema.double(description = "World X position (-30 to 30)."),
                        "py" to Schema.double(description = "World Y center position (-5 to 30)."),
                        "pz" to Schema.double(description = "World Z position (-30 to 30)."),
                        "rx" to Schema.double(description = "Rotation X in degrees."),
                        "ry" to Schema.double(description = "Rotation Y in degrees."),
                        "rz" to Schema.double(description = "Rotation Z in degrees."),
                        "sx" to Schema.double(description = "Scale X width (0.1 to 40)."),
                        "sy" to Schema.double(description = "Scale Y height (0.1 to 40)."),
                        "sz" to Schema.double(description = "Scale Z depth (0.1 to 40)."),
                        "colorHex" to Schema.string(description = "Hex color string like #3B82F6."),
                        "material" to Schema.enumeration(
                            values = ForgeMaterial.entries.map { it.name },
                            description = "Surface material."
                        ),
                        "canCollide" to Schema.boolean(description = "Whether physical collisions are enabled."),
                        "timeOfDay" to Schema.enumeration(
                            values = TimeOfDay.entries.map { it.name },
                            description = "Sky lighting preset for SET_LIGHTING."
                        )
                    ),
                    optionalProperties = listOf(
                        "targetName", "folderName", "kind", "shape",
                        "px", "py", "pz", "rx", "ry", "rz", "sx", "sy", "sz",
                        "colorHex", "material", "canCollide", "timeOfDay"
                    )
                )
            )
        )
    )

    private val luauSchema = Schema.obj(
        properties = mapOf(
            "scriptName" to Schema.string(description = "Filename ending in .luau"),
            "scriptType" to Schema.enumeration(listOf("Script", "LocalScript", "ModuleScript")),
            "parentTarget" to Schema.enumeration(listOf("ServerScriptService", "StarterPlayerScripts", "ReplicatedStorage", "Workspace")),
            "explanation" to Schema.string(description = "Clear explanation and Roblox Studio setup notes."),
            "code" to Schema.string(description = "Complete production-ready Roblox Luau code with type annotations and comments.")
        )
    )

    private fun buildSceneContextSummary(nodes: List<SceneNode>, selected: SceneNode?, lighting: LightingSettings): String {
        val folders = nodes.filter { it.isFolder }.joinToString(", ") { it.name }
        val sampleParts = nodes.filter { !it.isFolder }.take(35).joinToString("\n") { n ->
            "- ${n.name} (${n.kind.name}, ${n.shape.name}) pos=(${n.position.x},${n.position.y},${n.position.z}) scale=(${n.scale.x},${n.scale.y},${n.scale.z}) color=${n.colorHex} mat=${n.material.name}"
        }
        val selectedDesc = if (selected != null) {
            "Selected object: '${selected.name}' (${selected.shape.name}) at (${selected.position.x}, ${selected.position.y}, ${selected.position.z}) scale (${selected.scale.x}, ${selected.scale.y}, ${selected.scale.z}) color=${selected.colorHex}"
        } else {
            "Selected object: None"
        }
        return """
            Current Lighting: ${lighting.timeOfDay.name}, sky=${lighting.skyColorHex}, ambient=${lighting.ambientIntensity}
            Folders: ${folders.ifBlank { "None" }}
            Total Objects: ${nodes.count { !it.isFolder }}
            $selectedDesc
            Objects in Workspace:
            $sampleParts
        """.trimIndent()
    }

    suspend fun generateSceneOperations(
        prompt: String,
        nodes: List<SceneNode>,
        selected: SceneNode?,
        lighting: LightingSettings,
        modelChoice: AiModelChoice,
        temperature: Float,
        isWorldGeneration: Boolean = false
    ): Result<SceneAiPlanResult> {
        return try {
            val systemPrompt = """
                You are the 3D Scene Architect inside Forge AI Studio.
                Convert the user's request into a rich, well-proportioned set of 3D scene operations using primitive shapes (BOX, SPHERE, CYLINDER, CONE, WEDGE, TORUS, TERRAIN_PLANE).
                Rules:
                - Y=0 is the ground plane. A box of height sy=4 resting on the ground has py=2.0.
                - Compose buildings, castles, villages, trees, mountains, roads, and dungeons out of multiple distinct editable objects organized into folders (CREATE_FOLDER first, then CREATE_OBJECT with folderName).
                - Never merge everything into one object. For world generation requests, create 18-45 well-spaced objects across multiple region folders (e.g., CentralKingdom, Mountains, Forest, Village, Ruins, Roads).
                - For edits to the currently selected object (e.g. "make this taller" or "turn it neon"), use action=MODIFY_OBJECT with targetName="SELECTED" and include only the changed fields or full updated fields without rebuilding the scene.
                - Keep coordinates within -28..28 for X and Z.
            """.trimIndent()

            val config = generationConfig {
                this.temperature = temperature
                responseMimeType = "application/json"
                responseSchema = sceneActionSchema
            }

            val model = Firebase.ai.generativeModel(
                modelName = modelChoice.modelId,
                generationConfig = config,
                systemInstruction = content { text(systemPrompt) }
            )

            val fullPrompt = buildString {
                appendLine(buildSceneContextSummary(nodes, selected, lighting))
                appendLine()
                if (isWorldGeneration) {
                    appendLine("WORLD GENERATION REQUEST (organize into multiple region folders with distinct buildings, terrain, trees, roads, props):")
                } else {
                    appendLine("USER COMMAND:")
                }
                appendLine(prompt)
            }

            val response = withTimeout(TIMEOUT_MS) {
                model.generateContent(fullPrompt)
            }
            val jsonStr = response.text ?: throw IllegalStateException("Gemini returned an empty scene plan.")
            Result.success(parseScenePlanJson(jsonStr))
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Scene generation timed out", e)
            Result.failure(Exception("AI scene generation timed out after 60 seconds."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Scene generation failed", e)
            Result.failure(e)
        }
    }

    private fun parseScenePlanJson(jsonStr: String): SceneAiPlanResult {
        val root = JSONObject(jsonStr)
        val summary = root.optString("summary", "Applied AI scene updates.")
        val opsArr = root.optJSONArray("operations") ?: JSONArray()
        val ops = mutableListOf<SceneAiOperation>()

        for (i in 0 until opsArr.length()) {
            val o = opsArr.getJSONObject(i)
            val action = o.optString("action", "CREATE_OBJECT")
            val pos = if (o.has("px") || o.has("py") || o.has("pz")) {
                Vec3(
                    o.optDouble("px", 0.0).toFloat().coerceIn(-35f, 35f),
                    o.optDouble("py", 1.0).toFloat().coerceIn(-8f, 35f),
                    o.optDouble("pz", 0.0).toFloat().coerceIn(-35f, 35f)
                )
            } else null

            val rot = if (o.has("rx") || o.has("ry") || o.has("rz")) {
                Vec3(
                    o.optDouble("rx", 0.0).toFloat(),
                    o.optDouble("ry", 0.0).toFloat(),
                    o.optDouble("rz", 0.0).toFloat()
                )
            } else null

            val scale = if (o.has("sx") || o.has("sy") || o.has("sz")) {
                Vec3(
                    o.optDouble("sx", 2.0).toFloat().coerceIn(0.1f, 45f),
                    o.optDouble("sy", 2.0).toFloat().coerceIn(0.1f, 45f),
                    o.optDouble("sz", 2.0).toFloat().coerceIn(0.1f, 45f)
                )
            } else null

            val kind = NodeKind.entries.firstOrNull { it.name == o.optString("kind") } ?: NodeKind.PART
            val shape = SceneShape.entries.firstOrNull { it.name == o.optString("shape") } ?: SceneShape.BOX
            val mat = if (o.has("material")) ForgeMaterial.fromRaw(o.optString("material")) else null
            val tod = if (o.has("timeOfDay")) TimeOfDay.fromRaw(o.optString("timeOfDay")) else null

            ops.add(
                SceneAiOperation(
                    action = action,
                    targetName = o.optString("targetName").ifBlank { null },
                    name = o.optString("name", "GeneratedPart").ifBlank { "GeneratedPart" },
                    folderName = o.optString("folderName").ifBlank { null },
                    kind = kind,
                    shape = shape,
                    position = pos,
                    rotation = rot,
                    scale = scale,
                    colorHex = o.optString("colorHex").ifBlank { null },
                    material = mat,
                    canCollide = if (o.has("canCollide")) o.optBoolean("canCollide") else null,
                    timeOfDay = tod
                )
            )
        }
        return SceneAiPlanResult(summary, ops)
    }

    fun streamAssistantChat(
        history: List<AiChatMessage>,
        userPrompt: String,
        sceneSummary: String,
        modelChoice: AiModelChoice,
        temperature: Float
    ): Flow<String> = flow {
        val model = Firebase.ai.generativeModel(
            modelName = modelChoice.modelId,
            generationConfig = generationConfig { this.temperature = temperature },
            systemInstruction = content {
                text(
                    "You are the Forge AI Studio Assistant, an expert 3D game architect, level designer, and Roblox Studio export & Luau advisor. " +
                        "Never claim to execute scripts directly inside Roblox Studio runtime—explain clearly when exporting assets or scripts to Roblox Studio.\n\n" +
                        "Current Scene Context:\n$sceneSummary"
                )
            }
        )
        val chatHistory = history.takeLast(12).map { msg ->
            content(if (msg.isUser) "user" else "model") { text(msg.text) }
        }
        val chat = model.startChat(history = chatHistory)
        val acc = StringBuilder()
        withTimeout(TIMEOUT_MS) {
            chat.sendMessageStream(userPrompt).collect { chunk ->
                val part = chunk.text.orEmpty()
                if (part.isNotEmpty()) {
                    acc.append(part)
                    emit(acc.toString())
                }
            }
        }
    }

    suspend fun generateLuauScript(
        prompt: String,
        existingCode: String?,
        modelChoice: AiModelChoice
    ): Result<LuauAiResponse> {
        return try {
            val config = generationConfig {
                temperature = 0.35f
                responseMimeType = "application/json"
                responseSchema = luauSchema
            }
            val model = Firebase.ai.generativeModel(
                modelName = modelChoice.modelId,
                generationConfig = config,
                systemInstruction = content {
                    text(
                        "You are an expert Roblox Luau developer. Generate clean, idiomatic Luau scripts designed for Roblox Studio " +
                            "(using game:GetService, task.wait, typed Luau annotations, and clear inline comments). " +
                            "Note that Forge AI Studio runs a local preview engine and scripts are exported for Roblox Studio."
                    )
                }
            )
            val fullPrompt = if (!existingCode.isNullOrBlank()) {
                "Existing Luau Script:\n```lua\n$existingCode\n```\n\nRequest: $prompt"
            } else {
                "Create a Roblox Luau script for: $prompt"
            }
            val response = withTimeout(TIMEOUT_MS) { model.generateContent(fullPrompt) }
            val json = JSONObject(response.text ?: throw IllegalStateException("Empty Luau response"))
            Result.success(
                LuauAiResponse(
                    scriptName = json.optString("scriptName", "GeneratedScript.luau"),
                    scriptType = json.optString("scriptType", "Script"),
                    parentTarget = json.optString("parentTarget", "ServerScriptService"),
                    explanation = json.optString("explanation", "Generated Luau script ready for Roblox Studio."),
                    code = json.optString("code", "-- Empty script")
                )
            )
        } catch (e: TimeoutCancellationException) {
            Result.failure(Exception("Luau assistant timed out after 60 seconds."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Luau generation failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateConceptOrTextureImage(
        prompt: String,
        modelChoice: ImageModelChoice,
        aspect: ImageAspectOption,
        resolution: ImageResolutionOption
    ): Result<Bitmap> {
        return try {
            val aspectEnum = when (aspect) {
                ImageAspectOption.RATIO_1_1 -> AspectRatio.SQUARE_1x1
                ImageAspectOption.RATIO_16_9 -> AspectRatio.LANDSCAPE_16x9
                ImageAspectOption.RATIO_9_16 -> AspectRatio.PORTRAIT_9x16
                ImageAspectOption.RATIO_4_3 -> AspectRatio.LANDSCAPE_4x3
                ImageAspectOption.RATIO_3_4 -> AspectRatio.PORTRAIT_3x4
                ImageAspectOption.RATIO_3_2 -> AspectRatio.LANDSCAPE_3x2
                ImageAspectOption.RATIO_2_3 -> AspectRatio.PORTRAIT_2x3
            }
            val sizeEnum = when (resolution) {
                ImageResolutionOption.RES_1K -> ImageSize.SIZE_1K
                ImageResolutionOption.RES_2K -> ImageSize.SIZE_2K
                ImageResolutionOption.RES_4K -> ImageSize.SIZE_4K
            }
            val config = generationConfig {
                responseModalities = listOf(ResponseModality.IMAGE)
                imageConfig = ImageConfig.builder()
                    .setAspectRatio(aspectEnum)
                    .setImageSize(sizeEnum)
                    .build()
            }
            val model = Firebase.ai.generativeModel(
                modelName = modelChoice.modelId,
                generationConfig = config
            )
            val response = withTimeout(TIMEOUT_MS) { model.generateContent(prompt) }
            val imagePart = response.candidates.firstOrNull()
                ?.content?.parts?.filterIsInstance<ImagePart>()
                ?.firstOrNull()
            val bmp = imagePart?.image
                ?: return Result.failure(IllegalStateException("No image returned by ${modelChoice.modelId}."))
            Result.success(bmp)
        } catch (e: TimeoutCancellationException) {
            Result.failure(Exception("Image generation timed out after 60 seconds."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Image generation failed", e)
            Result.failure(e)
        }
    }

    suspend fun transcribeAudioCommand(
        wavBytes: ByteArray,
        modelChoice: AiModelChoice
    ): Result<String> {
        return try {
            val model = Firebase.ai.generativeModel(modelName = modelChoice.modelId)
            val response = withTimeout(TIMEOUT_MS) {
                model.generateContent(
                    content {
                        inlineData(wavBytes, "audio/wav")
                        text("Transcribe the spoken 3D game editor command accurately as plain text without extra commentary.")
                    }
                )
            }
            val text = response.text?.trim()
            if (text.isNullOrBlank()) {
                Result.failure(IllegalStateException("Could not transcribe speech from audio."))
            } else {
                Result.success(text)
            }
        } catch (e: TimeoutCancellationException) {
            Result.failure(Exception("Audio transcription timed out."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Audio transcription failed", e)
            Result.failure(e)
        }
    }

    suspend fun analyzeVideoReference(
        videoBytes: ByteArray,
        mimeType: String,
        prompt: String,
        modelChoice: AiModelChoice
    ): Result<String> {
        return try {
            if (videoBytes.size > 18 * 1024 * 1024) {
                return Result.failure(IllegalArgumentException("Video exceeds 18 MB inline payload limit. Please choose a shorter clip."))
            }
            val model = Firebase.ai.generativeModel(modelName = modelChoice.modelId)
            val response = withTimeout(TIMEOUT_MS) {
                model.generateContent(
                    content {
                        inlineData(videoBytes, mimeType)
                        text(
                            prompt.ifBlank {
                                "Analyze this reference video and break down the 3D environment layout, landmarks, lighting mood, and suggested Roblox Luau gameplay mechanics."
                            }
                        )
                    }
                )
            }
            val text = response.text?.trim()
            if (text.isNullOrBlank()) {
                Result.failure(IllegalStateException("Model returned empty video analysis."))
            } else {
                Result.success(text)
            }
        } catch (e: TimeoutCancellationException) {
            Result.failure(Exception("Video analysis timed out after 60 seconds."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Video analysis failed", e)
            Result.failure(e)
        }
    }

    suspend fun testConnection(modelChoice: AiModelChoice): Result<Pair<String, Long>> {
        return try {
            val start = System.currentTimeMillis()
            val model = Firebase.ai.generativeModel(modelName = modelChoice.modelId)
            val res = withTimeout(30_000L) {
                model.generateContent("Reply with exactly: FORGE_AI_ONLINE")
            }
            val elapsed = System.currentTimeMillis() - start
            val text = res.text?.trim().orEmpty().ifBlank { "Connected" }
            Result.success(text to elapsed)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Connection test failed", e)
            Result.failure(e)
        }
    }
}
