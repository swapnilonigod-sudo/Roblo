package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AiModelChoice
import com.example.model.ImageModelChoice
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.forgeSettingsDataStore by preferencesDataStore(name = "forge_studio_settings")

data class StudioSettings(
    val aiModel: AiModelChoice = AiModelChoice.GEMINI_3_8_FLASH,
    val imageModel: ImageModelChoice = ImageModelChoice.NANO_BANANA_2_1,
    val temperature: Float = 0.7f,
    val aiEnabled: Boolean = true,
    val snapEnabled: Boolean = false,
    val showGrid: Boolean = true,
    val showCollisions: Boolean = false,
    val external3dProviderUrl: String = ""
)

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val AI_MODEL = stringPreferencesKey("ai_model")
        val IMAGE_MODEL = stringPreferencesKey("image_model")
        val TEMPERATURE = floatPreferencesKey("temperature")
        val AI_ENABLED = booleanPreferencesKey("ai_enabled")
        val SNAP_ENABLED = booleanPreferencesKey("snap_enabled")
        val SHOW_GRID = booleanPreferencesKey("show_grid")
        val SHOW_COLLISIONS = booleanPreferencesKey("show_collisions")
        val EXTERNAL_3D_URL = stringPreferencesKey("external_3d_url")
    }

    val settingsFlow: Flow<StudioSettings> = context.forgeSettingsDataStore.data.map { prefs ->
        StudioSettings(
            aiModel = AiModelChoice.fromId(prefs[Keys.AI_MODEL]),
            imageModel = ImageModelChoice.fromId(prefs[Keys.IMAGE_MODEL]),
            temperature = prefs[Keys.TEMPERATURE] ?: 0.7f,
            aiEnabled = prefs[Keys.AI_ENABLED] ?: true,
            snapEnabled = prefs[Keys.SNAP_ENABLED] ?: false,
            showGrid = prefs[Keys.SHOW_GRID] ?: true,
            showCollisions = prefs[Keys.SHOW_COLLISIONS] ?: false,
            external3dProviderUrl = prefs[Keys.EXTERNAL_3D_URL] ?: ""
        )
    }

    suspend fun updateAiModel(model: AiModelChoice) {
        context.forgeSettingsDataStore.edit { it[Keys.AI_MODEL] = model.modelId }
    }

    suspend fun updateImageModel(model: ImageModelChoice) {
        context.forgeSettingsDataStore.edit { it[Keys.IMAGE_MODEL] = model.modelId }
    }

    suspend fun updateTemperature(temp: Float) {
        context.forgeSettingsDataStore.edit { it[Keys.TEMPERATURE] = temp.coerceIn(0f, 1.5f) }
    }

    suspend fun updateAiEnabled(enabled: Boolean) {
        context.forgeSettingsDataStore.edit { it[Keys.AI_ENABLED] = enabled }
    }

    suspend fun updateSnapEnabled(enabled: Boolean) {
        context.forgeSettingsDataStore.edit { it[Keys.SNAP_ENABLED] = enabled }
    }

    suspend fun updateShowGrid(show: Boolean) {
        context.forgeSettingsDataStore.edit { it[Keys.SHOW_GRID] = show }
    }

    suspend fun updateShowCollisions(show: Boolean) {
        context.forgeSettingsDataStore.edit { it[Keys.SHOW_COLLISIONS] = show }
    }

    suspend fun updateExternal3dUrl(url: String) {
        context.forgeSettingsDataStore.edit { it[Keys.EXTERNAL_3D_URL] = url.trim() }
    }
}
