package com.example.engine3d

import android.opengl.Matrix
import com.example.model.AxisConstraint
import com.example.model.SceneNode
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class Ray3D(
    val ox: Float, val oy: Float, val oz: Float,
    val dx: Float, val dy: Float, val dz: Float
)

object RayPicker {

    fun screenToRay(
        touchX: Float,
        touchY: Float,
        viewWidth: Int,
        viewHeight: Int,
        viewProjMatrix: FloatArray
    ): Ray3D? {
        if (viewWidth <= 0 || viewHeight <= 0) return null
        val inv = FloatArray(16)
        if (!Matrix.invertM(inv, 0, viewProjMatrix, 0)) return null

        val ndcX = (2f * touchX) / viewWidth - 1f
        val ndcY = 1f - (2f * touchY) / viewHeight

        val nearNdc = floatArrayOf(ndcX, ndcY, -1f, 1f)
        val farNdc = floatArrayOf(ndcX, ndcY, 1f, 1f)
        val nearWorld = FloatArray(4)
        val farWorld = FloatArray(4)

        Matrix.multiplyMV(nearWorld, 0, inv, 0, nearNdc, 0)
        Matrix.multiplyMV(farWorld, 0, inv, 0, farNdc, 0)

        if (abs(nearWorld[3]) < 1e-6f || abs(farWorld[3]) < 1e-6f) return null

        val nx = nearWorld[0] / nearWorld[3]
        val ny = nearWorld[1] / nearWorld[3]
        val nz = nearWorld[2] / nearWorld[3]

        val fx = farWorld[0] / farWorld[3]
        val fy = farWorld[1] / farWorld[3]
        val fz = farWorld[2] / farWorld[3]

        val vx = fx - nx
        val vy = fy - ny
        val vz = fz - nz
        val len = kotlin.math.sqrt(vx * vx + vy * vy + vz * vz)
        if (len < 1e-6f) return null

        return Ray3D(nx, ny, nz, vx / len, vy / len, vz / len)
    }

    fun pickGizmoAxis(ray: Ray3D, selectedNode: SceneNode, gizmoSize: Float): AxisConstraint? {
        val cx = selectedNode.position.x
        val cy = selectedNode.position.y
        val cz = selectedNode.position.z
        val r = gizmoSize * 0.28f

        var bestAxis: AxisConstraint? = null
        var bestT = Float.MAX_VALUE

        val xT = intersectAabb(
            ray,
            cx, cy - r, cz - r,
            cx + gizmoSize * 1.15f, cy + r, cz + r
        )
        if (xT != null && xT < bestT) {
            bestT = xT
            bestAxis = AxisConstraint.X
        }

        val yT = intersectAabb(
            ray,
            cx - r, cy, cz - r,
            cx + r, cy + gizmoSize * 1.15f, cz + r
        )
        if (yT != null && yT < bestT) {
            bestT = yT
            bestAxis = AxisConstraint.Y
        }

        val zT = intersectAabb(
            ray,
            cx - r, cy - r, cz,
            cx + r, cy + r, cz + gizmoSize * 1.15f
        )
        if (zT != null && zT < bestT) {
            bestT = zT
            bestAxis = AxisConstraint.Z
        }

        return bestAxis
    }

    fun pickSceneNode(ray: Ray3D, nodes: List<SceneNode>): SceneNode? {
        var closest: SceneNode? = null
        var minT = Float.MAX_VALUE

        for (node in nodes) {
            if (!node.visible || node.isFolder) continue
            val t = intersectNodeObb(ray, node)
            if (t != null && t < minT) {
                minT = t
                closest = node
            }
        }
        return closest
    }

    private fun intersectNodeObb(ray: Ray3D, node: SceneNode): Float? {
        val model = FloatArray(16)
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, node.position.x, node.position.y, node.position.z)
        Matrix.rotateM(model, 0, node.rotation.y, 0f, 1f, 0f)
        Matrix.rotateM(model, 0, node.rotation.x, 1f, 0f, 0f)
        Matrix.rotateM(model, 0, node.rotation.z, 0f, 0f, 1f)
        Matrix.scaleM(
            model, 0,
            node.scale.x.coerceAtLeast(0.1f),
            node.scale.y.coerceAtLeast(0.1f),
            node.scale.z.coerceAtLeast(0.1f)
        )

        val invModel = FloatArray(16)
        if (!Matrix.invertM(invModel, 0, model, 0)) return null

        val localOrig = FloatArray(4)
        val localDir = FloatArray(4)
        Matrix.multiplyMV(localOrig, 0, invModel, 0, floatArrayOf(ray.ox, ray.oy, ray.oz, 1f), 0)
        Matrix.multiplyMV(localDir, 0, invModel, 0, floatArrayOf(ray.dx, ray.dy, ray.dz, 0f), 0)

        val localRay = Ray3D(
            localOrig[0], localOrig[1], localOrig[2],
            localDir[0], localDir[1], localDir[2]
        )
        return intersectAabb(localRay, -0.52f, -0.52f, -0.52f, 0.52f, 0.52f, 0.52f)
    }

    fun intersectAabb(
        ray: Ray3D,
        minX: Float, minY: Float, minZ: Float,
        maxX: Float, maxY: Float, maxZ: Float
    ): Float? {
        var tMin = 0.001f
        var tMax = 5000f

        fun slab(orig: Float, dir: Float, bMin: Float, bMax: Float): Boolean {
            if (abs(dir) < 1e-6f) {
                return orig in bMin..bMax
            }
            var t1 = (bMin - orig) / dir
            var t2 = (bMax - orig) / dir
            if (t1 > t2) {
                val tmp = t1; t1 = t2; t2 = tmp
            }
            tMin = max(tMin, t1)
            tMax = min(tMax, t2)
            return tMin <= tMax
        }

        if (!slab(ray.ox, ray.dx, minX, maxX)) return null
        if (!slab(ray.oy, ray.dy, minY, maxY)) return null
        if (!slab(ray.oz, ray.dz, minZ, maxZ)) return null
        return tMin
    }
}
