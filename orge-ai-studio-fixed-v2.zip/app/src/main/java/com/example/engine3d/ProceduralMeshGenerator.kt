package com.example.engine3d

import com.example.model.CustomMeshData
import com.example.model.SceneShape
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class MeshBuffers(
    val vertexBuffer: FloatBuffer,
    val normalBuffer: FloatBuffer,
    val indexBuffer: ShortBuffer,
    val indexCount: Int,
    val triangleCount: Int,
    val rawVertices: FloatArray,
    val rawNormals: FloatArray,
    val rawIndices: IntArray
)

object ProceduralMeshGenerator {

    private val cachedPrimitives = mutableMapOf<SceneShape, MeshBuffers>()

    fun getMesh(shape: SceneShape, custom: CustomMeshData? = null): MeshBuffers {
        if (shape == SceneShape.CUSTOM_MESH && custom != null && custom.vertices.isNotEmpty() && custom.indices.isNotEmpty()) {
            return buildFromRaw(
                custom.vertices.toFloatArray(),
                custom.normals.toFloatArray(),
                custom.indices.toIntArray()
            )
        }
        return cachedPrimitives.getOrPut(shape) {
            when (shape) {
                SceneShape.BOX -> buildBox()
                SceneShape.SPHERE -> buildSphere(16, 12)
                SceneShape.CYLINDER -> buildCylinder(16)
                SceneShape.CONE -> buildCone(16)
                SceneShape.WEDGE -> buildWedge()
                SceneShape.TORUS -> buildTorus(18, 10, 0.35f, 0.14f)
                SceneShape.TERRAIN_PLANE -> buildTerrainPatch(10)
                SceneShape.CUSTOM_MESH -> buildBox()
            }
        }
    }

    fun triangleCountFor(shape: SceneShape, custom: CustomMeshData? = null): Int {
        return if (shape == SceneShape.CUSTOM_MESH && custom != null) {
            custom.triangleCount
        } else {
            getMesh(shape).triangleCount
        }
    }

    private fun buildFromRaw(verts: FloatArray, norms: FloatArray, inds: IntArray): MeshBuffers {
        val safeNorms = if (norms.size == verts.size) norms else FloatArray(verts.size) { i ->
            if (i % 3 == 1) 1f else 0f
        }
        val cappedInds = if (inds.size > 65000) inds.sliceArray(0 until 65000 - (65000 % 3)) else inds
        val shortInds = ShortArray(cappedInds.size) { cappedInds[it].toShort() }
        return MeshBuffers(
            vertexBuffer = toFloatBuffer(verts),
            normalBuffer = toFloatBuffer(safeNorms),
            indexBuffer = toShortBuffer(shortInds),
            indexCount = shortInds.size,
            triangleCount = shortInds.size / 3,
            rawVertices = verts,
            rawNormals = safeNorms,
            rawIndices = cappedInds
        )
    }

    private fun toFloatBuffer(data: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(data.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply { put(data); position(0) }

    private fun toShortBuffer(data: ShortArray): ShortBuffer =
        ByteBuffer.allocateDirect(data.size * 2)
            .order(ByteOrder.nativeOrder())
            .asShortBuffer()
            .apply { put(data); position(0) }

    private fun buildBox(): MeshBuffers {
        val h = 0.5f
        val verts = floatArrayOf(
            // Front (+Z)
            -h, -h, h,   h, -h, h,   h, h, h,   -h, h, h,
            // Back (-Z)
            h, -h, -h,  -h, -h, -h,  -h, h, -h,  h, h, -h,
            // Top (+Y)
            -h, h, h,    h, h, h,    h, h, -h,  -h, h, -h,
            // Bottom (-Y)
            -h, -h, -h,  h, -h, -h,  h, -h, h,  -h, -h, h,
            // Right (+X)
            h, -h, h,    h, -h, -h,  h, h, -h,   h, h, h,
            // Left (-X)
            -h, -h, -h, -h, -h, h,  -h, h, h,  -h, h, -h
        )
        val norms = floatArrayOf(
            0f, 0f, 1f,  0f, 0f, 1f,  0f, 0f, 1f,  0f, 0f, 1f,
            0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f,
            0f, 1f, 0f,  0f, 1f, 0f,  0f, 1f, 0f,  0f, 1f, 0f,
            0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f,
            1f, 0f, 0f,  1f, 0f, 0f,  1f, 0f, 0f,  1f, 0f, 0f,
            -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f
        )
        val inds = intArrayOf(
            0, 1, 2, 0, 2, 3,
            4, 5, 6, 4, 6, 7,
            8, 9, 10, 8, 10, 11,
            12, 13, 14, 12, 14, 15,
            16, 17, 18, 16, 18, 19,
            20, 21, 22, 20, 22, 23
        )
        return buildFromRaw(verts, norms, inds)
    }

    private fun buildWedge(): MeshBuffers {
        val h = 0.5f
        val slopeNy = 1f / sqrt(2f)
        val slopeNz = 1f / sqrt(2f)
        val vList = mutableListOf<Float>()
        val nList = mutableListOf<Float>()
        val iList = mutableListOf<Int>()

        fun addTri(
            x1: Float, y1: Float, z1: Float,
            x2: Float, y2: Float, z2: Float,
            x3: Float, y3: Float, z3: Float,
            nx: Float, ny: Float, nz: Float
        ) {
            val base = vList.size / 3
            vList.addAll(listOf(x1, y1, z1, x2, y2, z2, x3, y3, z3))
            repeat(3) { nList.addAll(listOf(nx, ny, nz)) }
            iList.addAll(listOf(base, base + 1, base + 2))
        }

        // Bottom (-Y)
        addTri(-h, -h, -h, h, -h, -h, h, -h, h, 0f, -1f, 0f)
        addTri(-h, -h, -h, h, -h, h, -h, -h, h, 0f, -1f, 0f)
        // Back (-Z)
        addTri(h, -h, -h, -h, -h, -h, -h, h, -h, 0f, 0f, -1f)
        addTri(h, -h, -h, -h, h, -h, h, h, -h, 0f, 0f, -1f)
        // Slope (+Y +Z)
        addTri(-h, -h, h, h, -h, h, h, h, -h, 0f, slopeNy, slopeNz)
        addTri(-h, -h, h, h, h, -h, -h, h, -h, 0f, slopeNy, slopeNz)
        // Left (-X)
        addTri(-h, -h, -h, -h, -h, h, -h, h, -h, -1f, 0f, 0f)
        // Right (+X)
        addTri(h, -h, h, h, -h, -h, h, h, -h, 1f, 0f, 0f)

        return buildFromRaw(vList.toFloatArray(), nList.toFloatArray(), iList.toIntArray())
    }

    private fun buildSphere(slices: Int, stacks: Int): MeshBuffers {
        val verts = mutableListOf<Float>()
        val norms = mutableListOf<Float>()
        val inds = mutableListOf<Int>()
        val r = 0.5f

        for (i in 0..stacks) {
            val phi = PI * i / stacks
            val sinPhi = sin(phi).toFloat()
            val cosPhi = cos(phi).toFloat()
            for (j in 0..slices) {
                val theta = 2.0 * PI * j / slices
                val x = (sinPhi * cos(theta)).toFloat()
                val y = cosPhi
                val z = (sinPhi * sin(theta)).toFloat()
                verts.addAll(listOf(x * r, y * r, z * r))
                norms.addAll(listOf(x, y, z))
            }
        }
        val stride = slices + 1
        for (i in 0 until stacks) {
            for (j in 0 until slices) {
                val a = i * stride + j
                val b = a + stride
                inds.addAll(listOf(a, b, a + 1, a + 1, b, b + 1))
            }
        }
        return buildFromRaw(verts.toFloatArray(), norms.toFloatArray(), inds.toIntArray())
    }

    private fun buildCylinder(segments: Int): MeshBuffers {
        val verts = mutableListOf<Float>()
        val norms = mutableListOf<Float>()
        val inds = mutableListOf<Int>()
        val r = 0.5f
        val h = 0.5f

        // Side wall
        for (i in 0..segments) {
            val angle = 2.0 * PI * i / segments
            val cx = cos(angle).toFloat()
            val cz = sin(angle).toFloat()
            verts.addAll(listOf(cx * r, h, cz * r))
            norms.addAll(listOf(cx, 0f, cz))
            verts.addAll(listOf(cx * r, -h, cz * r))
            norms.addAll(listOf(cx, 0f, cz))
        }
        for (i in 0 until segments) {
            val idx = i * 2
            inds.addAll(listOf(idx, idx + 1, idx + 2, idx + 2, idx + 1, idx + 3))
        }

        // Top & bottom caps
        val topCenterIdx = verts.size / 3
        verts.addAll(listOf(0f, h, 0f))
        norms.addAll(listOf(0f, 1f, 0f))
        for (i in 0..segments) {
            val angle = 2.0 * PI * i / segments
            verts.addAll(listOf(cos(angle).toFloat() * r, h, sin(angle).toFloat() * r))
            norms.addAll(listOf(0f, 1f, 0f))
        }
        for (i in 0 until segments) {
            inds.addAll(listOf(topCenterIdx, topCenterIdx + 1 + i + 1, topCenterIdx + 1 + i))
        }

        val botCenterIdx = verts.size / 3
        verts.addAll(listOf(0f, -h, 0f))
        norms.addAll(listOf(0f, -1f, 0f))
        for (i in 0..segments) {
            val angle = 2.0 * PI * i / segments
            verts.addAll(listOf(cos(angle).toFloat() * r, -h, sin(angle).toFloat() * r))
            norms.addAll(listOf(0f, -1f, 0f))
        }
        for (i in 0 until segments) {
            inds.addAll(listOf(botCenterIdx, botCenterIdx + 1 + i, botCenterIdx + 1 + i + 1))
        }

        return buildFromRaw(verts.toFloatArray(), norms.toFloatArray(), inds.toIntArray())
    }

    private fun buildCone(segments: Int): MeshBuffers {
        val verts = mutableListOf<Float>()
        val norms = mutableListOf<Float>()
        val inds = mutableListOf<Int>()
        val r = 0.5f
        val h = 0.5f
        val slopeLen = sqrt(r * r + (2f * h) * (2f * h))
        val ny = r / slopeLen
        val nr = (2f * h) / slopeLen

        for (i in 0 until segments) {
            val a1 = 2.0 * PI * i / segments
            val a2 = 2.0 * PI * (i + 1) / segments
            val aMid = (a1 + a2) * 0.5
            val base = verts.size / 3

            verts.addAll(listOf(0f, h, 0f))
            norms.addAll(listOf((cos(aMid) * nr).toFloat(), ny, (sin(aMid) * nr).toFloat()))

            verts.addAll(listOf(cos(a1).toFloat() * r, -h, sin(a1).toFloat() * r))
            norms.addAll(listOf((cos(a1) * nr).toFloat(), ny, (sin(a1) * nr).toFloat()))

            verts.addAll(listOf(cos(a2).toFloat() * r, -h, sin(a2).toFloat() * r))
            norms.addAll(listOf((cos(a2) * nr).toFloat(), ny, (sin(a2) * nr).toFloat()))

            inds.addAll(listOf(base, base + 2, base + 1))
        }

        val botCenter = verts.size / 3
        verts.addAll(listOf(0f, -h, 0f))
        norms.addAll(listOf(0f, -1f, 0f))
        for (i in 0..segments) {
            val a = 2.0 * PI * i / segments
            verts.addAll(listOf(cos(a).toFloat() * r, -h, sin(a).toFloat() * r))
            norms.addAll(listOf(0f, -1f, 0f))
        }
        for (i in 0 until segments) {
            inds.addAll(listOf(botCenter, botCenter + 1 + i, botCenter + 1 + i + 1))
        }

        return buildFromRaw(verts.toFloatArray(), norms.toFloatArray(), inds.toIntArray())
    }

    private fun buildTorus(majorSeg: Int, minorSeg: Int, majorR: Float, minorR: Float): MeshBuffers {
        val verts = mutableListOf<Float>()
        val norms = mutableListOf<Float>()
        val inds = mutableListOf<Int>()

        for (i in 0..majorSeg) {
            val u = 2.0 * PI * i / majorSeg
            val cosU = cos(u).toFloat()
            val sinU = sin(u).toFloat()
            for (j in 0..minorSeg) {
                val v = 2.0 * PI * j / minorSeg
                val cosV = cos(v).toFloat()
                val sinV = sin(v).toFloat()
                val x = (majorR + minorR * cosV) * cosU
                val y = minorR * sinV
                val z = (majorR + minorR * cosV) * sinU
                verts.addAll(listOf(x, y, z))
                norms.addAll(listOf(cosV * cosU, sinV, cosV * sinU))
            }
        }
        val stride = minorSeg + 1
        for (i in 0 until majorSeg) {
            for (j in 0 until minorSeg) {
                val a = i * stride + j
                val b = a + stride
                inds.addAll(listOf(a, b, a + 1, a + 1, b, b + 1))
            }
        }
        return buildFromRaw(verts.toFloatArray(), norms.toFloatArray(), inds.toIntArray())
    }

    private fun buildTerrainPatch(grid: Int): MeshBuffers {
        val verts = mutableListOf<Float>()
        val norms = mutableListOf<Float>()
        val inds = mutableListOf<Int>()

        fun heightAt(nx: Float, nz: Float): Float {
            val dist = sqrt(nx * nx + nz * nz)
            val islandMask = (1f - (dist * 1.45f).coerceIn(0f, 1f))
            val ripple = 0.08f * sin(nx * 6f) * cos(nz * 6f)
            return (-0.5f + islandMask * 0.95f + ripple).coerceIn(-0.5f, 0.5f)
        }

        for (iz in 0..grid) {
            val nz = iz.toFloat() / grid - 0.5f
            for (ix in 0..grid) {
                val nx = ix.toFloat() / grid - 0.5f
                val h = heightAt(nx, nz)
                verts.addAll(listOf(nx, h, nz))

                val eps = 0.04f
                val dx = heightAt(nx + eps, nz) - heightAt(nx - eps, nz)
                val dz = heightAt(nx, nz + eps) - heightAt(nx, nz - eps)
                val len = sqrt(dx * dx + (2f * eps) * (2f * eps) + dz * dz).coerceAtLeast(0.001f)
                norms.addAll(listOf(-dx / len, (2f * eps) / len, -dz / len))
            }
        }
        val stride = grid + 1
        for (iz in 0 until grid) {
            for (ix in 0 until grid) {
                val a = iz * stride + ix
                val b = a + stride
                inds.addAll(listOf(a, b, a + 1, a + 1, b, b + 1))
            }
        }
        return buildFromRaw(verts.toFloatArray(), norms.toFloatArray(), inds.toIntArray())
    }
}
