package com.example.model

import java.util.UUID

object ScenePresets {

    fun createStarterCitadelScene(): Pair<List<SceneNode>, List<LuauScript>> {
        val terrainFolderId = "fld_terrain"
        val kingdomFolderId = "fld_kingdom"
        val forestFolderId = "fld_forest"
        val propsFolderId = "fld_props"

        val nodes = listOf(
            SceneNode(
                id = terrainFolderId,
                name = "IslandTerrain",
                kind = NodeKind.FOLDER,
                parentId = SceneNode.WORKSPACE_ROOT_ID
            ),
            SceneNode(
                id = "part_ocean",
                name = "AbyssalWater",
                kind = NodeKind.TERRAIN,
                shape = SceneShape.BOX,
                parentId = terrainFolderId,
                position = Vec3(0f, -1.2f, 0f),
                scale = Vec3(36f, 0.4f, 36f),
                colorHex = "#1E40AF",
                material = ForgeMaterial.GLASS,
                transparency = 0.35f,
                canCollide = false
            ),
            SceneNode(
                id = "part_island",
                name = "CentralIsland",
                kind = NodeKind.TERRAIN,
                shape = SceneShape.TERRAIN_PLANE,
                parentId = terrainFolderId,
                position = Vec3(0f, -0.35f, 0f),
                scale = Vec3(22f, 0.9f, 22f),
                colorHex = "#2D6A4F",
                material = ForgeMaterial.GRASS
            ),
            SceneNode(
                id = "part_path",
                name = "RoyalCobbleRoad",
                kind = NodeKind.TERRAIN,
                shape = SceneShape.BOX,
                parentId = terrainFolderId,
                position = Vec3(0f, 0.14f, 4.2f),
                scale = Vec3(2.4f, 0.14f, 9.5f),
                colorHex = "#64748B",
                material = ForgeMaterial.BRICK
            ),
            SceneNode(
                id = kingdomFolderId,
                name = "CentralKingdom",
                kind = NodeKind.FOLDER,
                parentId = SceneNode.WORKSPACE_ROOT_ID
            ),
            SceneNode(
                id = "bld_keep",
                name = "CitadelKeep",
                kind = NodeKind.BUILDING,
                shape = SceneShape.BOX,
                parentId = kingdomFolderId,
                position = Vec3(0f, 2.1f, -2.5f),
                scale = Vec3(4.6f, 4.0f, 4.6f),
                colorHex = "#94A3B8",
                material = ForgeMaterial.BRICK
            ),
            SceneNode(
                id = "bld_spire",
                name = "CitadelRoof",
                kind = NodeKind.BUILDING,
                shape = SceneShape.CONE,
                parentId = kingdomFolderId,
                position = Vec3(0f, 5.1f, -2.5f),
                scale = Vec3(5.2f, 2.2f, 5.2f),
                colorHex = "#6D28D9",
                material = ForgeMaterial.METAL
            ),
            SceneNode(
                id = "bld_tower_l",
                name = "WestWatchtower",
                kind = NodeKind.BUILDING,
                shape = SceneShape.CYLINDER,
                parentId = kingdomFolderId,
                position = Vec3(-3.2f, 2.6f, -0.6f),
                scale = Vec3(1.5f, 5.0f, 1.5f),
                colorHex = "#CBD5E1",
                material = ForgeMaterial.ROCK
            ),
            SceneNode(
                id = "bld_tower_l_cap",
                name = "WestTowerCap",
                kind = NodeKind.BUILDING,
                shape = SceneShape.CONE,
                parentId = kingdomFolderId,
                position = Vec3(-3.2f, 5.8f, -0.6f),
                scale = Vec3(1.9f, 1.6f, 1.9f),
                colorHex = "#2563EB",
                material = ForgeMaterial.METAL
            ),
            SceneNode(
                id = "bld_tower_r",
                name = "EastWatchtower",
                kind = NodeKind.BUILDING,
                shape = SceneShape.CYLINDER,
                parentId = kingdomFolderId,
                position = Vec3(3.2f, 2.6f, -0.6f),
                scale = Vec3(1.5f, 5.0f, 1.5f),
                colorHex = "#CBD5E1",
                material = ForgeMaterial.ROCK
            ),
            SceneNode(
                id = "bld_tower_r_cap",
                name = "EastTowerCap",
                kind = NodeKind.BUILDING,
                shape = SceneShape.CONE,
                parentId = kingdomFolderId,
                position = Vec3(3.2f, 5.8f, -0.6f),
                scale = Vec3(1.9f, 1.6f, 1.9f),
                colorHex = "#2563EB",
                material = ForgeMaterial.METAL
            ),
            SceneNode(
                id = "bld_crystal",
                name = "AetherBeacon",
                kind = NodeKind.DECORATION,
                shape = SceneShape.SPHERE,
                parentId = kingdomFolderId,
                position = Vec3(0f, 6.8f, -2.5f),
                scale = Vec3(1.0f, 1.0f, 1.0f),
                colorHex = "#38BDF8",
                material = ForgeMaterial.NEON
            ),
            SceneNode(
                id = forestFolderId,
                name = "PineForest",
                kind = NodeKind.FOLDER,
                parentId = SceneNode.WORKSPACE_ROOT_ID
            ),
            SceneNode(
                id = "tree_1_trunk",
                name = "PineTrunk_01",
                kind = NodeKind.TREE,
                shape = SceneShape.CYLINDER,
                parentId = forestFolderId,
                position = Vec3(-6.4f, 1.0f, 3.2f),
                scale = Vec3(0.5f, 1.8f, 0.5f),
                colorHex = "#78350F",
                material = ForgeMaterial.WOOD
            ),
            SceneNode(
                id = "tree_1_crown",
                name = "PineCrown_01",
                kind = NodeKind.TREE,
                shape = SceneShape.CONE,
                parentId = forestFolderId,
                position = Vec3(-6.4f, 2.9f, 3.2f),
                scale = Vec3(2.2f, 2.6f, 2.2f),
                colorHex = "#15803D",
                material = ForgeMaterial.GRASS
            ),
            SceneNode(
                id = "tree_2_trunk",
                name = "PineTrunk_02",
                kind = NodeKind.TREE,
                shape = SceneShape.CYLINDER,
                parentId = forestFolderId,
                position = Vec3(6.2f, 1.0f, 3.8f),
                scale = Vec3(0.55f, 2.0f, 0.55f),
                colorHex = "#78350F",
                material = ForgeMaterial.WOOD
            ),
            SceneNode(
                id = "tree_2_crown",
                name = "PineCrown_02",
                kind = NodeKind.TREE,
                shape = SceneShape.CONE,
                parentId = forestFolderId,
                position = Vec3(6.2f, 3.1f, 3.8f),
                scale = Vec3(2.4f, 2.8f, 2.4f),
                colorHex = "#16A34A",
                material = ForgeMaterial.GRASS
            ),
            SceneNode(
                id = propsFolderId,
                name = "PropsAndRamp",
                kind = NodeKind.FOLDER,
                parentId = SceneNode.WORKSPACE_ROOT_ID
            ),
            SceneNode(
                id = "prop_ramp",
                name = "CastleApproachRamp",
                kind = NodeKind.PROP,
                shape = SceneShape.WEDGE,
                parentId = propsFolderId,
                position = Vec3(0f, 0.5f, 1.4f),
                scale = Vec3(2.4f, 0.8f, 2.2f),
                colorHex = "#94A3B8",
                material = ForgeMaterial.ROCK
            ),
            SceneNode(
                id = "prop_portal",
                name = "SpawnPortalRing",
                kind = NodeKind.DECORATION,
                shape = SceneShape.TORUS,
                parentId = propsFolderId,
                position = Vec3(0f, 1.6f, 7.6f),
                scale = Vec3(2.2f, 2.2f, 2.2f),
                colorHex = "#A855F7",
                material = ForgeMaterial.NEON,
                canCollide = false
            )
        )

        val scripts = listOf(
            LuauScript(
                id = "scr_sprint",
                name = "SprintSystem.luau",
                scriptType = "LocalScript",
                parentTarget = "StarterPlayerScripts",
                code = """-- Forge AI Studio -> Roblox Studio Starter Script
-- Place inside StarterPlayer > StarterPlayerScripts

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")

local player = Players.LocalPlayer
local WALK_SPEED = 16
local SPRINT_SPEED = 26

local function setSpeed(speed: number)
	local character = player.Character
	if not character then return end
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if humanoid then
		humanoid.WalkSpeed = speed
	end
end

UserInputService.InputBegan:Connect(function(input, gameProcessed)
	if gameProcessed then return end
	if input.KeyCode == Enum.KeyCode.LeftShift then
		setSpeed(SPRINT_SPEED)
	end
end)

UserInputService.InputEnded:Connect(function(input)
	if input.KeyCode == Enum.KeyCode.LeftShift then
		setSpeed(WALK_SPEED)
	end
end)
"""
            ),
            LuauScript(
                id = "scr_beacon",
                name = "AetherBeaconSpin.luau",
                scriptType = "Script",
                parentTarget = "ServerScriptService",
                code = """-- Animates the Citadel AetherBeacon in Roblox Workspace
local RunService = game:GetService("RunService")

local beacon = workspace:FindFirstChild("AetherBeacon", true)
if beacon and beacon:IsA("BasePart") then
	RunService.Heartbeat:Connect(function(dt: number)
		beacon.CFrame *= CFrame.Angles(0, math.rad(45) * dt, 0)
	end)
end
"""
            )
        )

        return nodes to scripts
    }

    fun createEmptyBaseplate(): Pair<List<SceneNode>, List<LuauScript>> {
        val baseplate = SceneNode(
            id = "baseplate_main",
            name = "Baseplate",
            kind = NodeKind.TERRAIN,
            shape = SceneShape.BOX,
            parentId = SceneNode.WORKSPACE_ROOT_ID,
            position = Vec3(0f, -0.5f, 0f),
            scale = Vec3(32f, 1f, 32f),
            colorHex = "#334155",
            material = ForgeMaterial.SMOOTH_PLASTIC
        )
        return listOf(baseplate) to emptyList()
    }

    val assetCatalog: List<AssetCatalogItem> = listOf(
        AssetCatalogItem(
            id = "cat_block",
            name = "Block Part",
            category = "Primitives",
            kind = NodeKind.PART,
            description = "Standard solid studio block",
            accentHex = "#3B82F6"
        ) { parent, pos ->
            listOf(
                SceneNode(
                    name = "BlockPart",
                    kind = NodeKind.PART,
                    shape = SceneShape.BOX,
                    parentId = parent,
                    position = Vec3(pos.x, pos.y + 1f, pos.z),
                    scale = Vec3(2f, 2f, 2f),
                    colorHex = "#3B82F6",
                    material = ForgeMaterial.SMOOTH_PLASTIC
                )
            )
        },
        AssetCatalogItem(
            id = "cat_tower",
            name = "Castle Watchtower",
            category = "Buildings",
            kind = NodeKind.BUILDING,
            description = "Stone tower cylinder with conical spire roof",
            accentHex = "#8B5CF6"
        ) { parent, pos ->
            val fId = "fld_${UUID.randomUUID().toString().take(6)}"
            listOf(
                SceneNode(id = fId, name = "Watchtower", kind = NodeKind.FOLDER, parentId = parent),
                SceneNode(
                    name = "TowerShaft",
                    kind = NodeKind.BUILDING,
                    shape = SceneShape.CYLINDER,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 2.5f, pos.z),
                    scale = Vec3(1.8f, 5.0f, 1.8f),
                    colorHex = "#94A3B8",
                    material = ForgeMaterial.BRICK
                ),
                SceneNode(
                    name = "TowerRoof",
                    kind = NodeKind.BUILDING,
                    shape = SceneShape.CONE,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 5.9f, pos.z),
                    scale = Vec3(2.3f, 1.8f, 2.3f),
                    colorHex = "#7C3AED",
                    material = ForgeMaterial.METAL
                )
            )
        },
        AssetCatalogItem(
            id = "cat_house",
            name = "Medieval Cottage",
            category = "Buildings",
            kind = NodeKind.BUILDING,
            description = "Timber and stone cottage with pitched roof",
            accentHex = "#F59E0B"
        ) { parent, pos ->
            val fId = "fld_${UUID.randomUUID().toString().take(6)}"
            listOf(
                SceneNode(id = fId, name = "MedievalCottage", kind = NodeKind.FOLDER, parentId = parent),
                SceneNode(
                    name = "CottageWalls",
                    kind = NodeKind.BUILDING,
                    shape = SceneShape.BOX,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 1.25f, pos.z),
                    scale = Vec3(3.4f, 2.5f, 2.8f),
                    colorHex = "#D6D3D1",
                    material = ForgeMaterial.BRICK
                ),
                SceneNode(
                    name = "CottageRoof",
                    kind = NodeKind.BUILDING,
                    shape = SceneShape.CONE,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 3.3f, pos.z),
                    scale = Vec3(4.2f, 1.6f, 3.6f),
                    colorHex = "#B45309",
                    material = ForgeMaterial.WOOD
                ),
                SceneNode(
                    name = "CottageDoor",
                    kind = NodeKind.PROP,
                    shape = SceneShape.BOX,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 0.85f, pos.z + 1.42f),
                    scale = Vec3(0.9f, 1.7f, 0.15f),
                    colorHex = "#78350F",
                    material = ForgeMaterial.WOOD
                )
            )
        },
        AssetCatalogItem(
            id = "cat_pine",
            name = "Pine Tree",
            category = "Trees",
            kind = NodeKind.TREE,
            description = "Stylized two-tier conifer tree",
            accentHex = "#10B981"
        ) { parent, pos ->
            val fId = "fld_${UUID.randomUUID().toString().take(6)}"
            listOf(
                SceneNode(id = fId, name = "PineTree", kind = NodeKind.FOLDER, parentId = parent),
                SceneNode(
                    name = "Trunk",
                    kind = NodeKind.TREE,
                    shape = SceneShape.CYLINDER,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 0.9f, pos.z),
                    scale = Vec3(0.45f, 1.8f, 0.45f),
                    colorHex = "#713F12",
                    material = ForgeMaterial.WOOD
                ),
                SceneNode(
                    name = "FoliageLower",
                    kind = NodeKind.TREE,
                    shape = SceneShape.CONE,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 2.3f, pos.z),
                    scale = Vec3(2.2f, 2.0f, 2.2f),
                    colorHex = "#15803D",
                    material = ForgeMaterial.GRASS
                ),
                SceneNode(
                    name = "FoliageUpper",
                    kind = NodeKind.TREE,
                    shape = SceneShape.CONE,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 3.5f, pos.z),
                    scale = Vec3(1.5f, 1.6f, 1.5f),
                    colorHex = "#22C55E",
                    material = ForgeMaterial.GRASS
                )
            )
        },
        AssetCatalogItem(
            id = "cat_mountain",
            name = "Mountain Peak",
            category = "Terrain",
            kind = NodeKind.TERRAIN,
            description = "Steep rocky peak with snow cap",
            accentHex = "#64748B"
        ) { parent, pos ->
            val fId = "fld_${UUID.randomUUID().toString().take(6)}"
            listOf(
                SceneNode(id = fId, name = "MountainPeak", kind = NodeKind.FOLDER, parentId = parent),
                SceneNode(
                    name = "MountainBase",
                    kind = NodeKind.TERRAIN,
                    shape = SceneShape.CONE,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 3.2f, pos.z),
                    scale = Vec3(7.0f, 6.4f, 7.0f),
                    colorHex = "#475569",
                    material = ForgeMaterial.ROCK
                ),
                SceneNode(
                    name = "SnowSummit",
                    kind = NodeKind.TERRAIN,
                    shape = SceneShape.CONE,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 5.2f, pos.z),
                    scale = Vec3(2.8f, 2.5f, 2.8f),
                    colorHex = "#F1F5F9",
                    material = ForgeMaterial.SAND
                )
            )
        },
        AssetCatalogItem(
            id = "cat_crate",
            name = "Supply Crate",
            category = "Props",
            kind = NodeKind.PROP,
            description = "Wooden storage crate prop",
            accentHex = "#D97706"
        ) { parent, pos ->
            listOf(
                SceneNode(
                    name = "SupplyCrate",
                    kind = NodeKind.PROP,
                    shape = SceneShape.BOX,
                    parentId = parent,
                    position = Vec3(pos.x, pos.y + 0.65f, pos.z),
                    scale = Vec3(1.3f, 1.3f, 1.3f),
                    colorHex = "#B45309",
                    material = ForgeMaterial.WOOD
                )
            )
        },
        AssetCatalogItem(
            id = "cat_table",
            name = "Tavern Table",
            category = "Furniture",
            kind = NodeKind.FURNITURE,
            description = "Wooden table with four corner legs",
            accentHex = "#92400E"
        ) { parent, pos ->
            val fId = "fld_${UUID.randomUUID().toString().take(6)}"
            listOf(
                SceneNode(id = fId, name = "TavernTable", kind = NodeKind.FOLDER, parentId = parent),
                SceneNode(
                    name = "TableTop",
                    kind = NodeKind.FURNITURE,
                    shape = SceneShape.BOX,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 1.0f, pos.z),
                    scale = Vec3(2.4f, 0.2f, 1.4f),
                    colorHex = "#92400E",
                    material = ForgeMaterial.WOOD
                ),
                SceneNode(
                    name = "TablePedestal",
                    kind = NodeKind.FURNITURE,
                    shape = SceneShape.BOX,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 0.45f, pos.z),
                    scale = Vec3(1.4f, 0.9f, 0.8f),
                    colorHex = "#78350F",
                    material = ForgeMaterial.WOOD
                )
            )
        },
        AssetCatalogItem(
            id = "cat_crystal",
            name = "Neon Energy Crystal",
            category = "Decorations",
            kind = NodeKind.DECORATION,
            description = "Emissive floating crystal shard",
            accentHex = "#06B6D4"
        ) { parent, pos ->
            listOf(
                SceneNode(
                    name = "EnergyCrystal",
                    kind = NodeKind.DECORATION,
                    shape = SceneShape.CONE,
                    parentId = parent,
                    position = Vec3(pos.x, pos.y + 1.4f, pos.z),
                    rotation = Vec3(12f, 25f, 0f),
                    scale = Vec3(0.9f, 2.2f, 0.9f),
                    colorHex = "#06B6D4",
                    material = ForgeMaterial.NEON
                )
            )
        },
        AssetCatalogItem(
            id = "cat_ramp",
            name = "Wedge Ramp",
            category = "Terrain",
            kind = NodeKind.PART,
            description = "Walkable Roblox-style WedgePart slope",
            accentHex = "#6366F1"
        ) { parent, pos ->
            listOf(
                SceneNode(
                    name = "WedgeRamp",
                    kind = NodeKind.PART,
                    shape = SceneShape.WEDGE,
                    parentId = parent,
                    position = Vec3(pos.x, pos.y + 0.75f, pos.z),
                    scale = Vec3(2.5f, 1.5f, 3.0f),
                    colorHex = "#64748B",
                    material = ForgeMaterial.ROCK
                )
            )
        },
        AssetCatalogItem(
            id = "cat_npc",
            name = "Guardian NPC Rig",
            category = "Models",
            kind = NodeKind.NPC,
            description = "Stylized blocky humanoid NPC placeholder",
            accentHex = "#EC4899"
        ) { parent, pos ->
            val fId = "fld_${UUID.randomUUID().toString().take(6)}"
            listOf(
                SceneNode(id = fId, name = "GuardianNPC", kind = NodeKind.FOLDER, parentId = parent),
                SceneNode(
                    name = "Torso",
                    kind = NodeKind.NPC,
                    shape = SceneShape.BOX,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 1.3f, pos.z),
                    scale = Vec3(0.9f, 1.0f, 0.5f),
                    colorHex = "#2563EB",
                    material = ForgeMaterial.METAL
                ),
                SceneNode(
                    name = "Head",
                    kind = NodeKind.NPC,
                    shape = SceneShape.SPHERE,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 2.15f, pos.z),
                    scale = Vec3(0.65f, 0.65f, 0.65f),
                    colorHex = "#FDE68A",
                    material = ForgeMaterial.SMOOTH_PLASTIC
                ),
                SceneNode(
                    name = "Legs",
                    kind = NodeKind.NPC,
                    shape = SceneShape.BOX,
                    parentId = fId,
                    position = Vec3(pos.x, pos.y + 0.4f, pos.z),
                    scale = Vec3(0.8f, 0.8f, 0.45f),
                    colorHex = "#1E293B",
                    material = ForgeMaterial.SMOOTH_PLASTIC
                )
            )
        }
    )

    val materialPaletteColors = listOf(
        "#3B82F6", "#8B5CF6", "#06B6D4", "#10B981",
        "#F59E0B", "#EF4444", "#EC4899", "#E2E8F0",
        "#94A3B8", "#475569", "#78350F", "#15803D"
    )
}
