package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.ForgeMaterial
import com.example.model.LightingSettings
import com.example.model.SceneNode
import com.example.model.ScenePresets
import com.example.model.TimeOfDay
import com.example.model.Vec3
import com.example.ui.theme.AxisBlue
import com.example.ui.theme.AxisGreen
import com.example.ui.theme.AxisRed
import com.example.ui.theme.ForgeBlue
import com.example.ui.theme.ForgeBorder
import com.example.ui.theme.ForgePanel
import com.example.ui.theme.ForgePurple
import com.example.ui.theme.ForgeSurface
import com.example.ui.theme.ForgeTextMuted
import com.example.ui.theme.ForgeTextPrimary
import com.example.ui.theme.ForgeTextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PropertiesInspectorPanel(
    selectedNode: SceneNode?,
    allFolders: List<SceneNode>,
    lighting: LightingSettings,
    onUpdateNode: (String, (SceneNode) -> SceneNode) -> Unit,
    onUpdateLighting: ((LightingSettings) -> LightingSettings) -> Unit,
    onApplyTimeOfDay: (TimeOfDay) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ForgePanel)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = if (selectedNode == null) Icons.Default.WbSunny else Icons.Default.Tune,
                contentDescription = null,
                tint = ForgePurple,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = if (selectedNode == null) "Lighting & World Inspector" else "Properties — ${selectedNode.name}",
                style = MaterialTheme.typography.titleSmall,
                color = ForgeTextPrimary
            )
        }
        HorizontalDivider(color = ForgeBorder)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (selectedNode == null) {
                Text("Sky & Time of Day Presets", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    TimeOfDay.entries.forEach { tod ->
                        val active = lighting.timeOfDay == tod
                        Surface(
                            onClick = { onApplyTimeOfDay(tod) },
                            color = if (active) ForgeBlue else ForgeSurface,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.border(1.dp, if (active) ForgeBlue else ForgeBorder, RoundedCornerShape(8.dp))
                        ) {
                            Text(tod.label, style = MaterialTheme.typography.labelMedium, color = ForgeTextPrimary, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
                        }
                    }
                }

                Text("Ambient Intensity: ${String.format("%.2f", lighting.ambientIntensity)}", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                Slider(
                    value = lighting.ambientIntensity,
                    onValueChange = { v -> onUpdateLighting { it.copy(ambientIntensity = v) } },
                    valueRange = 0.1f..1.0f,
                    colors = SliderDefaults.colors(thumbColor = ForgeBlue, activeTrackColor = ForgeBlue)
                )

                Text("Sun Intensity: ${String.format("%.2f", lighting.sunIntensity)}", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                Slider(
                    value = lighting.sunIntensity,
                    onValueChange = { v -> onUpdateLighting { it.copy(sunIntensity = v) } },
                    valueRange = 0.1f..1.8f,
                    colors = SliderDefaults.colors(thumbColor = ForgePurple, activeTrackColor = ForgePurple)
                )
                return@Column
            }

            // Object Identity
            OutlinedTextField(
                value = selectedNode.name,
                onValueChange = { newName -> onUpdateNode(selectedNode.id) { it.copy(name = newName.take(64)) } },
                label = { Text("Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("inspector_name_input")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Type: ${selectedNode.kind.label} / ${selectedNode.shape.label}", style = MaterialTheme.typography.bodySmall, color = ForgeTextSecondary)
            }

            // Parent Folder Selector
            var showParentMenu by remember { mutableStateOf(false) }
            val currentParentName = allFolders.firstOrNull { it.id == selectedNode.parentId }?.name ?: "Workspace"
            Box {
                OutlinedButton(
                    onClick = { showParentMenu = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Parent: $currentParentName", color = ForgeTextPrimary)
                }
                DropdownMenu(
                    expanded = showParentMenu,
                    onDismissRequest = { showParentMenu = false },
                    modifier = Modifier.background(ForgeSurface)
                ) {
                    DropdownMenuItem(
                        text = { Text("Workspace (Root)", color = ForgeTextPrimary) },
                        onClick = {
                            showParentMenu = false
                            onUpdateNode(selectedNode.id) { it.copy(parentId = SceneNode.WORKSPACE_ROOT_ID) }
                        }
                    )
                    allFolders.filter { it.id != selectedNode.id }.forEach { folder ->
                        DropdownMenuItem(
                            text = { Text(folder.name, color = ForgeTextPrimary) },
                            onClick = {
                                showParentMenu = false
                                onUpdateNode(selectedNode.id) { it.copy(parentId = folder.id) }
                            }
                        )
                    }
                }
            }

            if (!selectedNode.isFolder) {
                HorizontalDivider(color = ForgeBorder)
                Vec3EditorRow("Position", selectedNode.position, 0.5f) { newPos ->
                    onUpdateNode(selectedNode.id) { it.copy(position = newPos) }
                }
                Vec3EditorRow("Rotation (°)", selectedNode.rotation, 15f) { newRot ->
                    onUpdateNode(selectedNode.id) { it.copy(rotation = newRot) }
                }
                Vec3EditorRow("Scale", selectedNode.scale, 0.25f, minVal = 0.1f) { newScale ->
                    onUpdateNode(selectedNode.id) { it.copy(scale = newScale) }
                }

                HorizontalDivider(color = ForgeBorder)
                Text("Material (${selectedNode.material.robloxEnum})", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ForgeMaterial.entries.forEach { mat ->
                        val active = selectedNode.material == mat
                        Surface(
                            onClick = { onUpdateNode(selectedNode.id) { it.copy(material = mat) } },
                            color = if (active) ForgePurple else ForgeSurface,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.border(1.dp, if (active) ForgePurple else ForgeBorder, RoundedCornerShape(6.dp))
                        ) {
                            Text(
                                text = mat.label,
                                style = MaterialTheme.typography.labelMedium,
                                color = ForgeTextPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Text("Color (${selectedNode.colorHex})", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ScenePresets.materialPaletteColors.forEach { hex ->
                        val c = parseComposeColor(hex)
                        val active = selectedNode.colorHex.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(
                                    if (active) 2.5.dp else 1.dp,
                                    if (active) Color.White else ForgeBorder,
                                    CircleShape
                                )
                                .clickable { onUpdateNode(selectedNode.id) { it.copy(colorHex = hex) } }
                        )
                    }
                }

                HorizontalDivider(color = ForgeBorder)
                Text("Transparency: ${String.format("%.2f", selectedNode.transparency)}", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                Slider(
                    value = selectedNode.transparency,
                    onValueChange = { t -> onUpdateNode(selectedNode.id) { it.copy(transparency = t) } },
                    valueRange = 0f..0.9f
                )

                InspectorToggleRow("Visible", selectedNode.visible) { v ->
                    onUpdateNode(selectedNode.id) { it.copy(visible = v) }
                }
                InspectorToggleRow("CanCollide", selectedNode.canCollide) { v ->
                    onUpdateNode(selectedNode.id) { it.copy(canCollide = v) }
                }
                InspectorToggleRow("Anchored", selectedNode.anchored) { v ->
                    onUpdateNode(selectedNode.id) { it.copy(anchored = v) }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun Vec3EditorRow(
    title: String,
    value: Vec3,
    step: Float,
    minVal: Float = -200f,
    onChange: (Vec3) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary, fontWeight = FontWeight.SemiBold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AxisStepper("X", value.x, AxisRed, step, minVal, Modifier.weight(1f)) { nx ->
                onChange(value.copy(x = nx))
            }
            AxisStepper("Y", value.y, AxisGreen, step, minVal, Modifier.weight(1f)) { ny ->
                onChange(value.copy(y = ny))
            }
            AxisStepper("Z", value.z, AxisBlue, step, minVal, Modifier.weight(1f)) { nz ->
                onChange(value.copy(z = nz))
            }
        }
    }
}

@Composable
private fun AxisStepper(
    axis: String,
    v: Float,
    accent: Color,
    step: Float,
    minVal: Float,
    modifier: Modifier = Modifier,
    onValue: (Float) -> Unit
) {
    Surface(
        color = ForgeSurface,
        shape = RoundedCornerShape(6.dp),
        modifier = modifier.border(1.dp, ForgeBorder, RoundedCornerShape(6.dp))
    ) {
        Column(
            modifier = Modifier.padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "$axis: ${String.format("%.1f", v)}",
                style = MaterialTheme.typography.labelSmall,
                color = accent,
                fontWeight = FontWeight.Bold
            )
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                IconButton(
                    onClick = { onValue((v - step).coerceAtLeast(minVal)) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Decrease $axis", tint = ForgeTextPrimary, modifier = Modifier.size(14.dp))
                }
                IconButton(
                    onClick = { onValue(v + step) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Increase $axis", tint = ForgeTextPrimary, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

@Composable
private fun InspectorToggleRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = ForgeTextPrimary)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

private fun parseComposeColor(hex: String): Color {
    return try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (_: Exception) {
        ForgeBlue
    }
}
