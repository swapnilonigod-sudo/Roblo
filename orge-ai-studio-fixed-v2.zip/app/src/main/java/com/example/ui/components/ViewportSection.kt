package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AdsClick
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.ZoomOutMap
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.engine3d.ForgeGLSurfaceView
import com.example.engine3d.ProceduralMeshGenerator
import com.example.engine3d.ViewportRenderState
import com.example.model.AxisConstraint
import com.example.model.CameraPreset
import com.example.model.EditorTool
import com.example.model.PlayCameraMode
import com.example.model.SceneNode
import com.example.model.Vec3
import com.example.ui.theme.AxisBlue
import com.example.ui.theme.AxisGreen
import com.example.ui.theme.AxisRed
import com.example.ui.theme.ForgeBackground
import com.example.ui.theme.ForgeBlue
import com.example.ui.theme.ForgeBorder
import com.example.ui.theme.ForgeCyan
import com.example.ui.theme.ForgeEmerald
import com.example.ui.theme.ForgePanel
import com.example.ui.theme.ForgePurple
import com.example.ui.theme.ForgeRed
import com.example.ui.theme.ForgeSurface
import com.example.ui.theme.ForgeTextMuted
import com.example.ui.theme.ForgeTextPrimary
import com.example.ui.theme.ForgeTextSecondary
import com.example.viewmodel.ForgeStudioUiState
import kotlin.math.hypot
import kotlin.math.roundToInt

@Composable
fun ViewportSection(
    uiState: ForgeStudioUiState,
    showGrid: Boolean,
    showCollisions: Boolean,
    snapEnabled: Boolean,
    onToggleGrid: (Boolean) -> Unit,
    onToggleCollisions: (Boolean) -> Unit,
    onToggleSnap: (Boolean) -> Unit,
    onSelectTool: (EditorTool) -> Unit,
    onSelectAxis: (AxisConstraint) -> Unit,
    onSelectNode: (String?) -> Unit,
    onTransformLive: (String, Vec3, Vec3, Vec3) -> Unit,
    onTransformCommit: () -> Unit,
    onPlayLookDelta: (Float) -> Unit,
    onPlayJoystick: (Float, Float) -> Unit,
    onPlayJump: () -> Unit,
    onPlayCameraMode: (PlayCameraMode) -> Unit,
    onFpsMeasured: (Int) -> Unit,
    onCommandBarChange: (String) -> Unit,
    onExecuteAiCommand: (String) -> Unit,
    onToggleVoiceCommand: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var glViewRef by remember { mutableStateOf<ForgeGLSurfaceView?>(null) }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            onToggleVoiceCommand()
        }
    }

    val renderState = remember(
        uiState.nodes,
        uiState.selectedNodeId,
        uiState.lighting,
        uiState.activeTool,
        uiState.axisConstraint,
        showGrid,
        showCollisions,
        snapEnabled,
        uiState.isPlaying,
        uiState.playCameraMode,
        uiState.playerPosition,
        uiState.playerYaw,
        uiState.playerWalkCycle
    ) {
        ViewportRenderState(
            nodes = uiState.nodes,
            selectedNodeId = uiState.selectedNodeId,
            lighting = uiState.lighting,
            activeTool = uiState.activeTool,
            axisConstraint = uiState.axisConstraint,
            showGrid = showGrid,
            showCollisions = showCollisions,
            snapEnabled = snapEnabled,
            isPlaying = uiState.isPlaying,
            playCameraMode = uiState.playCameraMode,
            playerPosition = uiState.playerPosition,
            playerYaw = uiState.playerYaw,
            playerWalkCycle = uiState.playerWalkCycle
        )
    }

    val selectedNode = uiState.nodes.firstOrNull { it.id == uiState.selectedNodeId }
    val partCount = remember(uiState.nodes) { uiState.nodes.count { !it.isFolder && it.visible } }
    val totalTris = remember(uiState.nodes) {
        uiState.nodes.filter { !it.isFolder && it.visible }
            .sumOf { ProceduralMeshGenerator.triangleCountFor(it.shape, it.customMesh) }
    }

    Column(modifier = modifier.background(ForgeBackground)) {
        // Transform Tool & Camera Preset Strip
        if (!uiState.isPlaying) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ForgePanel.copy(alpha = 0.95f))
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                ToolChip(Icons.Default.AdsClick, "Select", uiState.activeTool == EditorTool.SELECT) {
                    onSelectTool(EditorTool.SELECT)
                }
                ToolChip(Icons.Default.OpenWith, "Move", uiState.activeTool == EditorTool.MOVE) {
                    onSelectTool(EditorTool.MOVE)
                }
                ToolChip(Icons.Default.RotateRight, "Rotate", uiState.activeTool == EditorTool.ROTATE) {
                    onSelectTool(EditorTool.ROTATE)
                }
                ToolChip(Icons.Default.ZoomOutMap, "Scale", uiState.activeTool == EditorTool.SCALE) {
                    onSelectTool(EditorTool.SCALE)
                }

                Spacer(Modifier.width(4.dp))
                AxisChip("Free", AxisConstraint.FREE, uiState.axisConstraint, ForgeTextSecondary, onSelectAxis)
                AxisChip("X", AxisConstraint.X, uiState.axisConstraint, AxisRed, onSelectAxis)
                AxisChip("Y", AxisConstraint.Y, uiState.axisConstraint, AxisGreen, onSelectAxis)
                AxisChip("Z", AxisConstraint.Z, uiState.axisConstraint, AxisBlue, onSelectAxis)

                Spacer(Modifier.width(4.dp))
                ToggleHudChip(Icons.Default.GridOn, "Grid", showGrid) { onToggleGrid(!showGrid) }
                ToggleHudChip(Icons.Default.ViewInAr, "Cols", showCollisions) { onToggleCollisions(!showCollisions) }
                ToggleHudChip(Icons.Default.CenterFocusStrong, "Snap", snapEnabled) { onToggleSnap(!snapEnabled) }

                Spacer(Modifier.width(4.dp))
                CameraPreset.entries.forEach { preset ->
                    Surface(
                        onClick = { glViewRef?.applyCameraPreset(preset) },
                        color = ForgeSurface,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .border(1.dp, ForgeBorder, RoundedCornerShape(6.dp))
                    ) {
                        Text(
                            text = preset.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = ForgeTextSecondary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                }
                if (selectedNode != null && !selectedNode.isFolder) {
                    Surface(
                        onClick = { glViewRef?.focusOnNode(selectedNode) },
                        color = ForgeBlue.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .border(1.dp, ForgeBlue, RoundedCornerShape(6.dp))
                    ) {
                        Text(
                            text = "Focus",
                            style = MaterialTheme.typography.labelMedium,
                            color = ForgeBlue,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // 3D OpenGL Viewport Canvas
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            AndroidView(
                factory = { ctx ->
                    ForgeGLSurfaceView(
                        context = ctx,
                        onSelectNode = onSelectNode,
                        onTransformLive = onTransformLive,
                        onTransformCommit = onTransformCommit,
                        onPlayLookDelta = onPlayLookDelta,
                        onFpsMeasured = onFpsMeasured
                    ).also { view ->
                        glViewRef = view
                        view.updateRenderState(renderState)
                    }
                },
                update = { view ->
                    glViewRef = view
                    view.updateRenderState(renderState)
                },
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("viewport_3d_canvas")
            )

            // Top-left Telemetry Overlay
            Surface(
                color = ForgeBackground.copy(alpha = 0.78f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(10.dp)
                    .border(1.dp, ForgeBorder, RoundedCornerShape(8.dp))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "${uiState.viewportFps} FPS",
                        style = MaterialTheme.typography.labelSmall,
                        color = ForgeEmerald,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "$partCount Parts • $totalTris Tris",
                        style = MaterialTheme.typography.labelSmall,
                        color = ForgeTextSecondary
                    )
                    if (selectedNode != null && !uiState.isPlaying) {
                        Text(
                            text = "Sel: ${selectedNode.name}",
                            style = MaterialTheme.typography.labelSmall,
                            color = ForgeCyan
                        )
                    }
                }
            }

            // Play Testing Engine Badge & Controls
            if (uiState.isPlaying) {
                Surface(
                    color = ForgeEmerald.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                        .border(1.dp, ForgeEmerald, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                        Text(
                            text = "FORGE INTERNAL PREVIEW ENGINE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = ForgeEmerald
                        )
                        Text(
                            text = "Local 3D Physics Preview (Not Roblox Engine)",
                            style = MaterialTheme.typography.labelSmall,
                            color = ForgeTextSecondary
                        )
                    }
                }

                // First/Third person toggle
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PlayCameraMode.entries.forEach { mode ->
                        val active = uiState.playCameraMode == mode
                        Surface(
                            onClick = { onPlayCameraMode(mode) },
                            color = if (active) ForgeBlue else ForgePanel.copy(alpha = 0.85f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .border(1.dp, if (active) ForgeBlue else ForgeBorder, RoundedCornerShape(8.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Visibility, contentDescription = null, tint = ForgeTextPrimary, modifier = Modifier.size(14.dp))
                                Text(mode.label, style = MaterialTheme.typography.labelMedium, color = ForgeTextPrimary)
                            }
                        }
                    }
                }

                // Virtual Thumbstick (bottom-left)
                VirtualThumbstick(
                    onMove = onPlayJoystick,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                )

                // Jump Button (bottom-right)
                Surface(
                    onClick = onPlayJump,
                    color = ForgeBlue.copy(alpha = 0.85f),
                    shape = CircleShape,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(16.dp)
                        .size(64.dp)
                        .border(2.dp, ForgeTextPrimary.copy(alpha = 0.6f), CircleShape)
                        .testTag("play_jump_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = "Jump", tint = ForgeTextPrimary, modifier = Modifier.size(28.dp))
                    }
                }
            }
        }

        // Universal AI Command Bar
        if (!uiState.isPlaying) {
            Surface(
                color = ForgePanel,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ForgeBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = ForgePurple,
                        modifier = Modifier.size(20.dp)
                    )
                    OutlinedTextField(
                        value = uiState.commandBarText,
                        onValueChange = onCommandBarChange,
                        placeholder = {
                            Text(
                                "AI Command: \"Build a medieval watchtower\", \"Make this taller\"...",
                                style = MaterialTheme.typography.bodySmall,
                                color = ForgeTextMuted,
                                maxLines = 1
                            )
                        },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyMedium.copy(color = ForgeTextPrimary),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ForgePurple,
                            unfocusedBorderColor = ForgeBorder,
                            focusedContainerColor = ForgeSurface,
                            unfocusedContainerColor = ForgeSurface
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = {
                            onExecuteAiCommand(uiState.commandBarText)
                        }),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_command_bar_input")
                    )

                    // Voice Command Button (RECORD_AUDIO runtime permission)
                    IconButton(
                        onClick = {
                            val hasPerm = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasPerm) {
                                onToggleVoiceCommand()
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (uiState.isRecordingAudio) ForgeRed else ForgeSurface)
                            .border(
                                1.dp,
                                if (uiState.isRecordingAudio) ForgeRed else ForgeBorder,
                                RoundedCornerShape(10.dp)
                            )
                            .testTag("voice_command_button")
                    ) {
                        Icon(
                            imageVector = if (uiState.isRecordingAudio) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = if (uiState.isRecordingAudio) "Stop Recording" else "Voice AI Command",
                            tint = ForgeTextPrimary
                        )
                    }

                    // Run AI Command Button
                    IconButton(
                        onClick = { onExecuteAiCommand(uiState.commandBarText) },
                        enabled = !uiState.isAiBusy && uiState.commandBarText.isNotBlank(),
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (uiState.commandBarText.isNotBlank()) ForgeBlue else ForgeSurface)
                            .testTag("ai_command_send_button")
                    ) {
                        if (uiState.isAiBusy) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = ForgeTextPrimary, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Execute AI Command", tint = ForgeTextPrimary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolChip(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        color = if (selected) ForgeBlue else ForgeSurface,
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .border(1.dp, if (selected) ForgeBlue else ForgeBorder, RoundedCornerShape(6.dp))
            .testTag("tool_${label.lowercase()}")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(icon, contentDescription = label, tint = ForgeTextPrimary, modifier = Modifier.size(14.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, color = ForgeTextPrimary)
        }
    }
}

@Composable
private fun AxisChip(
    label: String,
    axis: AxisConstraint,
    current: AxisConstraint,
    color: Color,
    onSelect: (AxisConstraint) -> Unit
) {
    val active = axis == current
    Surface(
        onClick = { onSelect(axis) },
        color = if (active) color.copy(alpha = 0.22f) else ForgeSurface,
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .border(1.dp, if (active) color else ForgeBorder, RoundedCornerShape(6.dp))
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = if (active) color else ForgeTextSecondary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun ToggleHudChip(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        color = if (active) ForgePurple.copy(alpha = 0.25f) else ForgeSurface,
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .border(1.dp, if (active) ForgePurple else ForgeBorder, RoundedCornerShape(6.dp))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(icon, contentDescription = label, tint = if (active) ForgePurple else ForgeTextSecondary, modifier = Modifier.size(13.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, color = if (active) ForgeTextPrimary else ForgeTextSecondary)
        }
    }
}

@Composable
private fun VirtualThumbstick(
    onMove: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var knobX by remember { mutableStateOf(0f) }
    var knobY by remember { mutableStateOf(0f) }
    val maxRadius = 44f

    Box(
        modifier = modifier
            .size(108.dp)
            .clip(CircleShape)
            .background(ForgePanel.copy(alpha = 0.65f))
            .border(1.5.dp, ForgeBorder, CircleShape)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = {
                        knobX = 0f; knobY = 0f
                        onMove(0f, 0f)
                    },
                    onDragCancel = {
                        knobX = 0f; knobY = 0f
                        onMove(0f, 0f)
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        var nx = knobX + dragAmount.x
                        var ny = knobY + dragAmount.y
                        val dist = hypot(nx, ny)
                        if (dist > maxRadius) {
                            nx = nx / dist * maxRadius
                            ny = ny / dist * maxRadius
                        }
                        knobX = nx
                        knobY = ny
                        onMove(nx / maxRadius, -ny / maxRadius)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .offset { IntOffset(knobX.roundToInt(), knobY.roundToInt()) }
                .size(42.dp)
                .clip(CircleShape)
                .background(ForgeBlue.copy(alpha = 0.85f))
                .border(1.dp, ForgeTextPrimary.copy(alpha = 0.7f), CircleShape)
        )
    }
}
