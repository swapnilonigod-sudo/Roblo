package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Forge AI Studio — Dark Charcoal Game Engine Palette with Blue & Purple Accents
val ForgeBackground = Color(0xFF0B0D14)
val ForgePanel = Color(0xFF121521)
val ForgeSurface = Color(0xFF181C2B)
val ForgeSurfaceRaised = Color(0xFF21263B)
val ForgeSurfaceHover = Color(0xFF282F47)
val ForgeBorder = Color(0xFF2B334D)
val ForgeBorderBright = Color(0xFF3D496E)

val ForgeBlue = Color(0xFF3B82F6)
val ForgeBlueBright = Color(0xFF60A5FA)
val ForgeBlueContainer = Color(0xFF1D3461)

val ForgePurple = Color(0xFF8B5CF6)
val ForgePurpleBright = Color(0xFFA78BFA)
val ForgePurpleContainer = Color(0xFF2E1E59)

val ForgeCyan = Color(0xFF06B6D4)
val ForgeEmerald = Color(0xFF10B981)
val ForgeEmeraldContainer = Color(0xFF0D3D2E)
val ForgeAmber = Color(0xFFF59E0B)
val ForgeAmberContainer = Color(0xFF422C0A)
val ForgeRed = Color(0xFFEF4444)
val ForgeRedContainer = Color(0xFF4A1619)

val ForgeTextPrimary = Color(0xFFF1F5F9)
val ForgeTextSecondary = Color(0xFF94A3B8)
val ForgeTextMuted = Color(0xFF64748B)

// Gizmo / Axis Colors
val AxisRed = Color(0xFFFF4D6A)
val AxisGreen = Color(0xFF22E584)
val AxisBlue = Color(0xFF3898FF)
