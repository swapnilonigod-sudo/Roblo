package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.ImageAspectOption
import com.example.model.ImageResolutionOption
import com.example.model.WorldRegionPlan
import com.example.ui.theme.ForgeBackground
import com.example.ui.theme.ForgeBlue
import com.example.ui.theme.ForgeBorder
import com.example.ui.theme.ForgeEmerald
import com.example.ui.theme.ForgePanel
import com.example.ui.theme.ForgePurple
import com.example.ui.theme.ForgeRed
import com.example.ui.theme.ForgeSurface
import com.example.ui.theme.ForgeTextMuted
import com.example.ui.theme.ForgeTextPrimary
import com.example.ui.theme.ForgeTextSecondary
import com.example.viewmodel.ForgeStudioUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiStudioPanel(
    uiState: ForgeStudioUiState,
    aiEnabled: Boolean,
    onExecuteSceneCommand: (String) -> Unit,
    onGenerateWorld: (String) -> Unit,
    onRegenerateRegion: (WorldRegionPlan) -> Unit,
    onSendChatMessage: (String) -> Unit,
    onGenerateTextureImage: (String, ImageAspectOption, ImageResolutionOption) -> Unit,
    onAnalyzeVideo: (ByteArray, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ForgePanel)
    ) {
        if (!aiEnabled) {
            Surface(
                color = ForgePurple.copy(alpha = 0.16f),
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "Non-AI Mode is active. Enable Firebase AI Logic in AI & Settings to run Gemini generation.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ForgeTextPrimary,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }

        TabRow(selectedTabIndex = selectedTab, containerColor = ForgePanel, contentColor = ForgePurple) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("AI Builder", maxLines = 1) })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("World Gen", maxLines = 1) })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Textures", maxLines = 1) })
            Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Video Ref", maxLines = 1) })
        }

        when (selectedTab) {
            0 -> AiBuilderAndChatTab(
                uiState = uiState,
                onExecuteSceneCommand = onExecuteSceneCommand,
                onSendChatMessage = onSendChatMessage
            )
            1 -> WorldGeneratorTab(
                uiState = uiState,
                onGenerateWorld = onGenerateWorld,
                onRegenerateRegion = onRegenerateRegion
            )
            2 -> TextureImageGenTab(
                uiState = uiState,
                onGenerateTextureImage = onGenerateTextureImage
            )
            3 -> VideoReferenceTab(
                uiState = uiState,
                onAnalyzeVideo = onAnalyzeVideo,
                onBuildFromAnalysis = onExecuteSceneCommand
            )
        }
    }
}

@Composable
private fun AiBuilderAndChatTab(
    uiState: ForgeStudioUiState,
    onExecuteSceneCommand: (String) -> Unit,
    onSendChatMessage: (String) -> Unit
) {
    var prompt by remember { mutableStateOf("") }
    val quickActions = listOf(
        "Build a giant medieval castle with 4 corner towers",
        "Add a pine forest with 12 trees around the island",
        "Create a PvP arena with glowing neon pillars",
        "Add roads connecting all regions",
        "Change lighting to Midnight",
        "Make the selected object taller and Neon cyan"
    )

    Column(modifier = Modifier.fillMaxSize().padding(10.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            quickActions.forEach { cmd ->
                Surface(
                    onClick = { onExecuteSceneCommand(cmd) },
                    color = ForgeSurface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.border(1.dp, ForgePurple.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                ) {
                    Text(
                        text = cmd,
                        style = MaterialTheme.typography.labelSmall,
                        color = ForgeTextSecondary,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(uiState.aiChatMessages, key = { it.id }) { msg ->
                Surface(
                    color = if (msg.isUser) ForgeBlue.copy(alpha = 0.22f) else ForgeSurface,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            if (msg.isUser) ForgeBlue.copy(alpha = 0.5f) else ForgeBorder,
                            RoundedCornerShape(10.dp)
                        )
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = if (msg.isUser) "You" else "Forge AI Architect",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (msg.isUser) ForgeBlue else ForgePurple
                        )
                        Text(msg.text, style = MaterialTheme.typography.bodySmall, color = ForgeTextPrimary)
                        if (msg.actionSummary != null) {
                            Text(
                                text = "Applied: ${msg.actionSummary}",
                                style = MaterialTheme.typography.labelSmall,
                                color = ForgeEmerald
                            )
                        }
                    }
                }
            }

            if (uiState.aiStreamingText.isNotEmpty()) {
                item {
                    Surface(
                        color = ForgeSurface,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().border(1.dp, ForgePurple, RoundedCornerShape(10.dp))
                    ) {
                        Text(
                            text = uiState.aiStreamingText,
                            style = MaterialTheme.typography.bodySmall,
                            color = ForgeTextPrimary,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            placeholder = { Text("Build in 3D or ask game design advice...") },
            maxLines = 3,
            modifier = Modifier.fillMaxWidth().testTag("ai_builder_prompt_input")
        )
        Spacer(Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    val p = prompt
                    prompt = ""
                    onExecuteSceneCommand(p)
                },
                enabled = !uiState.isAiBusy && prompt.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = ForgePurple),
                modifier = Modifier.weight(1f).testTag("ai_apply_to_scene_button")
            ) {
                if (uiState.isAiBusy) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = ForgeTextPrimary, strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                }
                Spacer(Modifier.size(6.dp))
                Text("Build in 3D")
            }
            OutlinedButton(
                onClick = {
                    val p = prompt
                    prompt = ""
                    onSendChatMessage(p)
                },
                enabled = !uiState.isAiBusy && prompt.isNotBlank(),
                modifier = Modifier.weight(0.8f).testTag("ai_chat_ask_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(Modifier.size(5.dp))
                Text("Ask Chat")
            }
        }
    }
}

@Composable
private fun WorldGeneratorTab(
    uiState: ForgeStudioUiState,
    onGenerateWorld: (String) -> Unit,
    onRegenerateRegion: (WorldRegionPlan) -> Unit
) {
    var worldPrompt by remember {
        mutableStateOf(
            "Create a fantasy anime island with a central kingdom castle, rocky mountain ridge, pine forest, coastal village, ancient ruins, volcanic crater, and connecting roads."
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("AI Multi-Region World Generator", style = MaterialTheme.typography.titleSmall, color = ForgeTextPrimary)
        Text(
            text = "Generates separate editable regions organized into Scene Explorer folders so you can tweak or regenerate any zone independently.",
            style = MaterialTheme.typography.bodySmall,
            color = ForgeTextSecondary
        )

        OutlinedTextField(
            value = worldPrompt,
            onValueChange = { worldPrompt = it },
            label = { Text("World Blueprint Prompt") },
            minLines = 3,
            maxLines = 5,
            modifier = Modifier.fillMaxWidth().testTag("world_gen_prompt_input")
        )

        Button(
            onClick = { onGenerateWorld(worldPrompt) },
            enabled = !uiState.isAiBusy && worldPrompt.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = ForgeBlue),
            modifier = Modifier.fillMaxWidth().testTag("generate_world_button")
        ) {
            if (uiState.isAiBusy) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = ForgeTextPrimary, strokeWidth = 2.dp)
                Spacer(Modifier.size(6.dp))
                Text(uiState.aiStatusText)
            } else {
                Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.size(6.dp))
                Text("Generate Editable 3D World")
            }
        }

        if (uiState.worldRegions.isNotEmpty()) {
            HorizontalDivider(color = ForgeBorder)
            Text("Generated Region Folders (${uiState.worldRegions.size})", style = MaterialTheme.typography.titleSmall, color = ForgePurple)
            uiState.worldRegions.forEach { region ->
                Surface(
                    color = ForgeSurface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, ForgeBorder, RoundedCornerShape(8.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(region.regionName, style = MaterialTheme.typography.titleSmall, color = ForgeTextPrimary)
                            Text(
                                text = "${region.objectCount} objects • Center (${region.centerX.toInt()}, ${region.centerZ.toInt()})",
                                style = MaterialTheme.typography.labelSmall,
                                color = ForgeTextSecondary
                            )
                        }
                        OutlinedButton(
                            onClick = { onRegenerateRegion(region) },
                            enabled = !uiState.isAiBusy
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.size(4.dp))
                            Text("Regen")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TextureImageGenTab(
    uiState: ForgeStudioUiState,
    onGenerateTextureImage: (String, ImageAspectOption, ImageResolutionOption) -> Unit
) {
    var prompt by remember { mutableStateOf("Seamless stylized medieval stone brick wall texture with moss and subtle blue runes, game asset") }
    var aspect by remember { mutableStateOf(ImageAspectOption.RATIO_1_1) }
    var resolution by remember { mutableStateOf(ImageResolutionOption.RES_1K) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("AI Texture & Concept Art Studio", style = MaterialTheme.typography.titleSmall, color = ForgeTextPrimary)
        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            label = { Text("Texture or Concept Art Prompt") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
        )

        Text("Aspect Ratio", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ImageAspectOption.entries.forEach { opt ->
                val active = aspect == opt
                Surface(
                    onClick = { aspect = opt },
                    color = if (active) ForgeBlue else ForgeSurface,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.border(1.dp, if (active) ForgeBlue else ForgeBorder, RoundedCornerShape(6.dp))
                ) {
                    Text(opt.label, style = MaterialTheme.typography.labelMedium, color = ForgeTextPrimary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                }
            }
        }

        Text("Resolution", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ImageResolutionOption.entries.forEach { res ->
                val active = resolution == res
                Surface(
                    onClick = { resolution = res },
                    color = if (active) ForgePurple else ForgeSurface,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.border(1.dp, if (active) ForgePurple else ForgeBorder, RoundedCornerShape(6.dp))
                ) {
                    Text(res.label, style = MaterialTheme.typography.labelMedium, color = ForgeTextPrimary, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                }
            }
        }

        Button(
            onClick = { onGenerateTextureImage(prompt, aspect, resolution) },
            enabled = !uiState.isImageGenerating && prompt.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = ForgePurple),
            modifier = Modifier.fillMaxWidth().testTag("generate_texture_button")
        ) {
            if (uiState.isImageGenerating) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = ForgeTextPrimary, strokeWidth = 2.dp)
                Spacer(Modifier.size(8.dp))
                Text("Synthesizing ${resolution.label} Image (30-60s)...")
            } else {
                Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.size(6.dp))
                Text("Generate Texture / Concept")
            }
        }

        if (uiState.imageGenError != null) {
            Text(
                text = "Error: ${uiState.imageGenError}",
                style = MaterialTheme.typography.bodySmall,
                color = ForgeRed
            )
        }

        uiState.generatedImage?.let { bmp ->
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = "Generated Game Texture Concept",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.dp, ForgeBorder, RoundedCornerShape(10.dp)),
                contentScale = ContentScale.Fit
            )
        }
    }
}

@Composable
private fun VideoReferenceTab(
    uiState: ForgeStudioUiState,
    onAnalyzeVideo: (ByteArray, String, String) -> Unit,
    onBuildFromAnalysis: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("Break down the 3D level layout, biome regions, lighting style, and Luau game mechanics shown in this video.") }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val bytes = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                }
                val mime = context.contentResolver.getType(uri) ?: "video/mp4"
                if (bytes != null) {
                    onAnalyzeVideo(bytes, mime, prompt)
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Video Reference Analyzer (Gemini)", style = MaterialTheme.typography.titleSmall, color = ForgeTextPrimary)
        Text(
            text = "Pick a short gameplay or level-design clip (under 18 MB) using Android Photo Picker to extract 3D environment plans and Roblox mechanic ideas.",
            style = MaterialTheme.typography.bodySmall,
            color = ForgeTextSecondary
        )
        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            label = { Text("Analysis Focus") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = {
                videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
            },
            enabled = !uiState.isVideoAnalyzing,
            colors = ButtonDefaults.buttonColors(containerColor = ForgeBlue),
            modifier = Modifier.fillMaxWidth().testTag("pick_video_analyze_button")
        ) {
            if (uiState.isVideoAnalyzing) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = ForgeTextPrimary, strokeWidth = 2.dp)
                Spacer(Modifier.size(8.dp))
                Text("Analyzing Video Clip...")
            } else {
                Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.size(6.dp))
                Text("Select Video & Analyze")
            }
        }

        if (uiState.videoAnalysisError != null) {
            Text(uiState.videoAnalysisError, style = MaterialTheme.typography.bodySmall, color = ForgeRed)
        }

        if (uiState.videoAnalysisResult != null) {
            Surface(
                color = ForgeSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, ForgeBorder, RoundedCornerShape(10.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(uiState.videoAnalysisResult, style = MaterialTheme.typography.bodySmall, color = ForgeTextPrimary)
                    Button(
                        onClick = {
                            onBuildFromAnalysis(
                                "Build a 3D scene inspired by this video reference analysis:\n${uiState.videoAnalysisResult}"
                            )
                        },
                        enabled = !uiState.isAiBusy,
                        colors = ButtonDefaults.buttonColors(containerColor = ForgePurple),
                        modifier = Modifier.fillMaxWidth().testTag("build_from_video_button")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.size(6.dp))
                        Text("Build 3D Scene from Analysis")
                    }
                }
            }
        }
    }
}
