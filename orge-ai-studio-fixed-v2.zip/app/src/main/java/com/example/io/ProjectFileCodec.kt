package com.example.io

import com.example.model.ForgeMaterial
import com.example.model.LightingSettings
import com.example.model.LuauScript
import com.example.model.NodeKind
import com.example.model.SceneNode
import com.example.model.SceneShape
import com.example.model.TimeOfDay
import com.example.model.Vec3
import org.json.JSONArray
import org.json.JSONObject

data class PortableForgeProject(
    val name: String,
    val description: String,
    val lighting: LightingSettings,
    val nodes: List<SceneNode>,
    val scripts: List<LuauScript>
)

object ProjectFileCodec {

    fun encode(project: PortableForgeProject): String {
        val root = JSONObject()
        root.put("format", "forge-ai-studio-project-v1")
        root.put("name", project.name)
        root.put("description", project.description)
        root.put(
            "lighting",
            JSONObject().apply {
                put("ambientIntensity", project.lighting.ambientIntensity.toDouble())
                put("sunIntensity", project.lighting.sunIntensity.toDouble())
                put("skyColorHex", project.lighting.skyColorHex)
                put("fogEnabled", project.lighting.fogEnabled)
                put("timeOfDay", project.lighting.timeOfDay.name)
            }
        )

        val nodesArr = JSONArray()
        for (n in project.nodes) {
            nodesArr.put(
                JSONObject().apply {
                    put("id", n.id)
                    put("name", n.name)
                    put("kind", n.kind.name)
                    put("shape", n.shape.name)
                    put("parentId", n.parentId)
                    put("px", n.position.x.toDouble())
                    put("py", n.position.y.toDouble())
                    put("pz", n.position.z.toDouble())
                    put("rx", n.rotation.x.toDouble())
                    put("ry", n.rotation.y.toDouble())
                    put("rz", n.rotation.z.toDouble())
                    put("sx", n.scale.x.toDouble())
                    put("sy", n.scale.y.toDouble())
                    put("sz", n.scale.z.toDouble())
                    put("colorHex", n.colorHex)
                    put("material", n.material.name)
                    put("visible", n.visible)
                    put("canCollide", n.canCollide)
                    put("anchored", n.anchored)
                    put("transparency", n.transparency.toDouble())
                    put("expanded", n.expanded)
                }
            )
        }
        root.put("nodes", nodesArr)

        val scriptsArr = JSONArray()
        for (s in project.scripts) {
            scriptsArr.put(
                JSONObject().apply {
                    put("id", s.id)
                    put("name", s.name)
                    put("scriptType", s.scriptType)
                    put("parentTarget", s.parentTarget)
                    put("code", s.code)
                }
            )
        }
        root.put("scripts", scriptsArr)

        return root.toString(2)
    }

    fun decode(jsonString: String): Result<PortableForgeProject> {
        return try {
            val root = JSONObject(jsonString)
            val name = root.optString("name", "Imported Forge Project").ifBlank { "Imported Forge Project" }
            val desc = root.optString("description", "")
            val lObj = root.optJSONObject("lighting")
            val lighting = if (lObj != null) {
                LightingSettings(
                    ambientIntensity = lObj.optDouble("ambientIntensity", 0.44).toFloat(),
                    sunIntensity = lObj.optDouble("sunIntensity", 0.96).toFloat(),
                    skyColorHex = lObj.optString("skyColorHex", "#111629"),
                    fogEnabled = lObj.optBoolean("fogEnabled", true),
                    timeOfDay = TimeOfDay.fromRaw(lObj.optString("timeOfDay"))
                )
            } else LightingSettings()

            val nodesArr = root.optJSONArray("nodes") ?: JSONArray()
            val nodes = mutableListOf<SceneNode>()
            for (i in 0 until nodesArr.length()) {
                val o = nodesArr.getJSONObject(i)
                nodes.add(
                    SceneNode(
                        id = o.optString("id"),
                        name = o.optString("name", "Part"),
                        kind = NodeKind.entries.firstOrNull { it.name == o.optString("kind") } ?: NodeKind.PART,
                        shape = SceneShape.entries.firstOrNull { it.name == o.optString("shape") } ?: SceneShape.BOX,
                        parentId = o.optString("parentId", SceneNode.WORKSPACE_ROOT_ID),
                        position = Vec3(
                            o.optDouble("px", 0.0).toFloat(),
                            o.optDouble("py", 0.5).toFloat(),
                            o.optDouble("pz", 0.0).toFloat()
                        ),
                        rotation = Vec3(
                            o.optDouble("rx", 0.0).toFloat(),
                            o.optDouble("ry", 0.0).toFloat(),
                            o.optDouble("rz", 0.0).toFloat()
                        ),
                        scale = Vec3(
                            o.optDouble("sx", 2.0).toFloat().coerceAtLeast(0.05f),
                            o.optDouble("sy", 1.0).toFloat().coerceAtLeast(0.05f),
                            o.optDouble("sz", 2.0).toFloat().coerceAtLeast(0.05f)
                        ),
                        colorHex = o.optString("colorHex", "#3B82F6"),
                        material = ForgeMaterial.fromRaw(o.optString("material")),
                        visible = o.optBoolean("visible", true),
                        canCollide = o.optBoolean("canCollide", true),
                        anchored = o.optBoolean("anchored", true),
                        transparency = o.optDouble("transparency", 0.0).toFloat().coerceIn(0f, 0.95f),
                        expanded = o.optBoolean("expanded", true)
                    )
                )
            }

            val scriptsArr = root.optJSONArray("scripts") ?: JSONArray()
            val scripts = mutableListOf<LuauScript>()
            for (i in 0 until scriptsArr.length()) {
                val s = scriptsArr.getJSONObject(i)
                scripts.add(
                    LuauScript(
                        id = s.optString("id"),
                        name = s.optString("name", "Script.luau"),
                        scriptType = s.optString("scriptType", "Script"),
                        parentTarget = s.optString("parentTarget", "ServerScriptService"),
                        code = s.optString("code", "")
                    )
                )
            }

            Result.success(PortableForgeProject(name, desc, lighting, nodes, scripts))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
