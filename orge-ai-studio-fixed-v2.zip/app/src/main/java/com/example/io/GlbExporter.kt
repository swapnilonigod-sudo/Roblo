package com.example.io

import android.util.Base64
import com.example.engine3d.ProceduralMeshGenerator
import com.example.model.LuauScript
import com.example.model.SceneNode
import com.example.model.Vec3
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object GlbExporter {

    private data class MeshAccessorSlice(
        val posAccessorIdx: Int,
        val normAccessorIdx: Int,
        val idxAccessorIdx: Int
    )

    fun exportGlb(nodes: List<SceneNode>, scaleMultiplier: Float = 1f): ByteArray {
        val (gltfJson, binBytes) = buildGltfPackage(nodes, scaleMultiplier, embedBinInJson = false)
        val jsonBytesRaw = gltfJson.toString().toByteArray(Charsets.UTF_8)
        val jsonPad = (4 - (jsonBytesRaw.size % 4)) % 4
        val jsonBytes = jsonBytesRaw + ByteArray(jsonPad) { 0x20 } // space padding for JSON chunk

        val binPad = (4 - (binBytes.size % 4)) % 4
        val paddedBin = binBytes + ByteArray(binPad) { 0x00 }

        val totalLength = 12 + 8 + jsonBytes.size + 8 + paddedBin.size
        val out = ByteBuffer.allocate(totalLength).order(ByteOrder.LITTLE_ENDIAN)

        // GLB Header
        out.putInt(0x46546C67) // "glTF"
        out.putInt(2)          // version 2
        out.putInt(totalLength)

        // JSON Chunk
        out.putInt(jsonBytes.size)
        out.putInt(0x4E4F534A) // "JSON"
        out.put(jsonBytes)

        // BIN Chunk
        out.putInt(paddedBin.size)
        out.putInt(0x004E4942) // "BIN\0"
        out.put(paddedBin)

        return out.array()
    }

    fun exportGltfJson(nodes: List<SceneNode>, scaleMultiplier: Float = 1f): String {
        val (gltfJson, _) = buildGltfPackage(nodes, scaleMultiplier, embedBinInJson = true)
        return gltfJson.toString(2)
    }

    fun exportObj(nodes: List<SceneNode>, scaleMultiplier: Float = 1f): Pair<String, String> {
        val exportable = nodes.filter { !it.isFolder && it.visible }
        val objSb = StringBuilder()
        val mtlSb = StringBuilder()
        objSb.appendLine("# Forge AI Studio Wavefront OBJ Export")
        objSb.appendLine("# Compatible with Roblox Studio MeshPart / 3D Importer")
        objSb.appendLine("mtllib forge_materials.mtl")
        objSb.appendLine()

        var vertexOffset = 1
        var normalOffset = 1
        val seenMaterials = mutableSetOf<String>()

        for (node in exportable) {
            val safeName = node.name.replace(Regex("[^A-Za-z0-9_\\-]"), "_").ifBlank { "Part" }
            val matName = "mat_${safeName}_${node.material.name}"
            if (seenMaterials.add(matName)) {
                val (r, g, b) = parseRgb(node.colorHex)
                mtlSb.appendLine("newmtl $matName")
                mtlSb.appendLine("Kd $r $g $b")
                mtlSb.appendLine("d ${1f - node.transparency}")
                mtlSb.appendLine()
            }

            objSb.appendLine("o $safeName")
            objSb.appendLine("usemtl $matName")

            val mesh = ProceduralMeshGenerator.getMesh(node.shape, node.customMesh)
            val verts = mesh.rawVertices
            val norms = mesh.rawNormals
            val inds = mesh.rawIndices

            val mat = buildTransformMatrix(node, scaleMultiplier)
            val vCount = verts.size / 3
            for (i in 0 until vCount) {
                val vx = verts[i * 3]
                val vy = verts[i * 3 + 1]
                val vz = verts[i * 3 + 2]
                val tv = transformPoint(mat, vx, vy, vz)
                objSb.appendLine("v ${tv[0]} ${tv[1]} ${tv[2]}")
            }
            for (i in 0 until vCount) {
                val nx = norms[i * 3]
                val ny = norms[i * 3 + 1]
                val nz = norms[i * 3 + 2]
                val tn = transformNormal(node.rotation, nx, ny, nz)
                objSb.appendLine("vn ${tn[0]} ${tn[1]} ${tn[2]}")
            }
            for (i in inds.indices step 3) {
                if (i + 2 >= inds.size) break
                val a = inds[i] + vertexOffset
                val b = inds[i + 1] + vertexOffset
                val c = inds[i + 2] + vertexOffset
                val na = inds[i] + normalOffset
                val nb = inds[i + 1] + normalOffset
                val nc = inds[i + 2] + normalOffset
                objSb.appendLine("f $a//$na $b//$nb $c//$nc")
            }
            objSb.appendLine()
            vertexOffset += vCount
            normalOffset += vCount
        }

        return objSb.toString() to mtlSb.toString()
    }

    fun exportRobloxManifest(
        projectName: String,
        nodes: List<SceneNode>,
        scripts: List<LuauScript>,
        scaleMultiplier: Float
    ): String {
        val parts = nodes.filter { !it.isFolder }
        val folders = nodes.filter { it.isFolder }
        val assetsArr = JSONArray()
        for (node in parts) {
            val tris = ProceduralMeshGenerator.triangleCountFor(node.shape, node.customMesh)
            assetsArr.put(
                JSONObject().apply {
                    put("id", node.id)
                    put("name", node.name)
                    put("parentFolder", nodes.firstOrNull { it.id == node.parentId }?.name ?: "Workspace")
                    put("kind", node.kind.label)
                    put("robloxClassSuggestion", if (node.shape.name == "BOX") "Part" else "MeshPart")
                    put("robloxMaterial", node.material.robloxEnum)
                    put("colorHex", node.colorHex)
                    put("triangles", tris)
                    put("position", JSONArray(listOf(node.position.x * scaleMultiplier, node.position.y * scaleMultiplier, node.position.z * scaleMultiplier)))
                    put("rotationDeg", JSONArray(listOf(node.rotation.x, node.rotation.y, node.rotation.z)))
                    put("scale", JSONArray(listOf(node.scale.x * scaleMultiplier, node.scale.y * scaleMultiplier, node.scale.z * scaleMultiplier)))
                    put("canCollide", node.canCollide)
                    put("anchored", node.anchored)
                }
            )
        }
        val scriptsArr = JSONArray()
        for (scr in scripts) {
            scriptsArr.put(
                JSONObject().apply {
                    put("name", scr.name)
                    put("robloxScriptClass", scr.scriptType)
                    put("recommendedService", scr.parentTarget)
                    put("lineCount", scr.code.lines().size)
                }
            )
        }

        return JSONObject().apply {
            put("generator", "Forge AI Studio")
            put("projectName", projectName)
            put("targetEngine", "Roblox Studio (via GLB / glTF / OBJ 3D Importer)")
            put("scaleMultiplier", scaleMultiplier)
            put("folderCount", folders.size)
            put("assetCount", parts.size)
            put("scriptCount", scripts.size)
            put("assets", assetsArr)
            put("scripts", scriptsArr)
            put(
                "robloxImportGuide",
                JSONArray(
                    listOf(
                        "1. Open Roblox Studio and select Home > Import 3D (or Asset Manager > Bulk Import).",
                        "2. Choose the exported .glb (recommended) or .obj file.",
                        "3. Keep 'Anchored' enabled for static architecture and verify CollisionFidelity.",
                        "4. Copy exported .luau scripts into the recommended Roblox services listed in scripts[]."
                    )
                )
            )
        }.toString(2)
    }

    private fun buildGltfPackage(
        nodes: List<SceneNode>,
        scaleMultiplier: Float,
        embedBinInJson: Boolean
    ): Pair<JSONObject, ByteArray> {
        val exportable = nodes.filter { !it.isFolder && it.visible }
        val binStream = ByteArrayOutputStream()
        val bufferViews = JSONArray()
        val accessors = JSONArray()
        val materials = JSONArray()
        val meshes = JSONArray()
        val gltfNodes = JSONArray()
        val rootNodeIndices = JSONArray()

        val cachedShapeSlices = mutableMapOf<String, MeshAccessorSlice>()

        fun appendBytesAligned(bytes: ByteArray): Int {
            while (binStream.size() % 4 != 0) binStream.write(0)
            val offset = binStream.size()
            binStream.write(bytes)
            return offset
        }

        for ((idx, node) in exportable.withIndex()) {
            val cacheKey = if (node.customMesh != null) "custom_${node.id}" else node.shape.name
            val slice = cachedShapeSlices.getOrPut(cacheKey) {
                val mesh = ProceduralMeshGenerator.getMesh(node.shape, node.customMesh)
                val vBytes = floatArrayToLeBytes(mesh.rawVertices)
                val nBytes = floatArrayToLeBytes(mesh.rawNormals)
                val shortInds = ShortArray(mesh.rawIndices.size) { mesh.rawIndices[it].toShort() }
                val iBytes = shortArrayToLeBytes(shortInds)

                var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var minZ = Float.MAX_VALUE
                var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE; var maxZ = -Float.MAX_VALUE
                for (i in mesh.rawVertices.indices step 3) {
                    val x = mesh.rawVertices[i]; val y = mesh.rawVertices[i + 1]; val z = mesh.rawVertices[i + 2]
                    minX = min(minX, x); minY = min(minY, y); minZ = min(minZ, z)
                    maxX = max(maxX, x); maxY = max(maxY, y); maxZ = max(maxZ, z)
                }

                val vOffset = appendBytesAligned(vBytes)
                val vBvIdx = bufferViews.length()
                bufferViews.put(JSONObject().put("buffer", 0).put("byteOffset", vOffset).put("byteLength", vBytes.size).put("target", 34962))

                val nOffset = appendBytesAligned(nBytes)
                val nBvIdx = bufferViews.length()
                bufferViews.put(JSONObject().put("buffer", 0).put("byteOffset", nOffset).put("byteLength", nBytes.size).put("target", 34962))

                val iOffset = appendBytesAligned(iBytes)
                val iBvIdx = bufferViews.length()
                bufferViews.put(JSONObject().put("buffer", 0).put("byteOffset", iOffset).put("byteLength", iBytes.size).put("target", 34963))

                val posAccIdx = accessors.length()
                accessors.put(
                    JSONObject()
                        .put("bufferView", vBvIdx)
                        .put("componentType", 5126)
                        .put("count", mesh.rawVertices.size / 3)
                        .put("type", "VEC3")
                        .put("min", JSONArray(listOf(minX, minY, minZ)))
                        .put("max", JSONArray(listOf(maxX, maxY, maxZ)))
                )
                val normAccIdx = accessors.length()
                accessors.put(
                    JSONObject()
                        .put("bufferView", nBvIdx)
                        .put("componentType", 5126)
                        .put("count", mesh.rawNormals.size / 3)
                        .put("type", "VEC3")
                )
                val idxAccIdx = accessors.length()
                accessors.put(
                    JSONObject()
                        .put("bufferView", iBvIdx)
                        .put("componentType", 5123)
                        .put("count", shortInds.size)
                        .put("type", "SCALAR")
                )
                MeshAccessorSlice(posAccIdx, normAccIdx, idxAccIdx)
            }

            val (r, g, b) = parseRgb(node.colorHex)
            val alpha = (1f - node.transparency).coerceIn(0.05f, 1f)
            val pbr = JSONObject()
                .put("baseColorFactor", JSONArray(listOf(r, g, b, alpha)))
                .put("metallicFactor", node.material.metallic)
                .put("roughnessFactor", node.material.roughness)
            val matObj = JSONObject()
                .put("name", "${node.name}_Mat")
                .put("pbrMetallicRoughness", pbr)
            if (alpha < 0.99f) {
                matObj.put("alphaMode", "BLEND")
            }
            if (node.material.emissive > 0.1f) {
                matObj.put("emissiveFactor", JSONArray(listOf(r * node.material.emissive, g * node.material.emissive, b * node.material.emissive)))
            }
            val matIdx = materials.length()
            materials.put(matObj)

            val primitive = JSONObject()
                .put("attributes", JSONObject().put("POSITION", slice.posAccessorIdx).put("NORMAL", slice.normAccessorIdx))
                .put("indices", slice.idxAccessorIdx)
                .put("material", matIdx)

            val meshIdx = meshes.length()
            meshes.put(JSONObject().put("name", node.name).put("primitives", JSONArray().put(primitive)))

            val quat = eulerDegToQuaternion(node.rotation.x, node.rotation.y, node.rotation.z)
            val nodeIdx = gltfNodes.length()
            gltfNodes.put(
                JSONObject()
                    .put("name", node.name)
                    .put("mesh", meshIdx)
                    .put("translation", JSONArray(listOf(node.position.x * scaleMultiplier, node.position.y * scaleMultiplier, node.position.z * scaleMultiplier)))
                    .put("rotation", JSONArray(listOf(quat[0], quat[1], quat[2], quat[3])))
                    .put("scale", JSONArray(listOf(node.scale.x * scaleMultiplier, node.scale.y * scaleMultiplier, node.scale.z * scaleMultiplier)))
            )
            rootNodeIndices.put(nodeIdx)
        }

        val binBytes = binStream.toByteArray()
        val bufferObj = JSONObject().put("byteLength", binBytes.size)
        if (embedBinInJson) {
            val b64 = Base64.encodeToString(binBytes, Base64.NO_WRAP)
            bufferObj.put("uri", "data:application/octet-stream;base64,$b64")
        }

        val gltf = JSONObject()
            .put("asset", JSONObject().put("version", "2.0").put("generator", "Forge AI Studio"))
            .put("scene", 0)
            .put("scenes", JSONArray().put(JSONObject().put("name", "ForgeScene").put("nodes", rootNodeIndices)))
            .put("nodes", gltfNodes)
            .put("meshes", meshes)
            .put("materials", materials)
            .put("accessors", accessors)
            .put("bufferViews", bufferViews)
            .put("buffers", JSONArray().put(bufferObj))

        return gltf to binBytes
    }

    private fun parseRgb(hex: String): Triple<Float, Float, Float> {
        return try {
            val clean = hex.removePrefix("#").trim()
            val rgb = clean.toLong(16).toInt()
            val r = ((rgb shr 16) and 0xFF) / 255f
            val g = ((rgb shr 8) and 0xFF) / 255f
            val b = (rgb and 0xFF) / 255f
            Triple(r, g, b)
        } catch (_: Exception) {
            Triple(0.23f, 0.51f, 0.96f)
        }
    }

    private fun eulerDegToQuaternion(rxDeg: Float, ryDeg: Float, rzDeg: Float): FloatArray {
        val rx = Math.toRadians(rxDeg.toDouble()) * 0.5
        val ry = Math.toRadians(ryDeg.toDouble()) * 0.5
        val rz = Math.toRadians(rzDeg.toDouble()) * 0.5
        val cx = cos(rx); val sx = sin(rx)
        val cy = cos(ry); val sy = sin(ry)
        val cz = cos(rz); val sz = sin(rz)
        // Y-X-Z intrinsic order
        val w = (cy * cx * cz + sy * sx * sz).toFloat()
        val x = (cy * sx * cz + sy * cx * sz).toFloat()
        val y = (sy * cx * cz - cy * sx * sz).toFloat()
        val z = (cy * cx * sz - sy * sx * cz).toFloat()
        return floatArrayOf(x, y, z, w)
    }

    private fun floatArrayToLeBytes(arr: FloatArray): ByteArray {
        val bb = ByteBuffer.allocate(arr.size * 4).order(ByteOrder.LITTLE_ENDIAN)
        for (f in arr) bb.putFloat(f)
        return bb.array()
    }

    private fun shortArrayToLeBytes(arr: ShortArray): ByteArray {
        val bb = ByteBuffer.allocate(arr.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (s in arr) bb.putShort(s)
        return bb.array()
    }

    private fun buildTransformMatrix(node: SceneNode, scaleMult: Float): FloatArray {
        val m = FloatArray(16)
        android.opengl.Matrix.setIdentityM(m, 0)
        android.opengl.Matrix.translateM(m, 0, node.position.x * scaleMult, node.position.y * scaleMult, node.position.z * scaleMult)
        android.opengl.Matrix.rotateM(m, 0, node.rotation.y, 0f, 1f, 0f)
        android.opengl.Matrix.rotateM(m, 0, node.rotation.x, 1f, 0f, 0f)
        android.opengl.Matrix.rotateM(m, 0, node.rotation.z, 0f, 0f, 1f)
        android.opengl.Matrix.scaleM(m, 0, node.scale.x * scaleMult, node.scale.y * scaleMult, node.scale.z * scaleMult)
        return m
    }

    private fun transformPoint(m: FloatArray, x: Float, y: Float, z: Float): FloatArray {
        val out = FloatArray(4)
        android.opengl.Matrix.multiplyMV(out, 0, m, 0, floatArrayOf(x, y, z, 1f), 0)
        return out
    }

    private fun transformNormal(rot: Vec3, nx: Float, ny: Float, nz: Float): FloatArray {
        val m = FloatArray(16)
        android.opengl.Matrix.setIdentityM(m, 0)
        android.opengl.Matrix.rotateM(m, 0, rot.y, 0f, 1f, 0f)
        android.opengl.Matrix.rotateM(m, 0, rot.x, 1f, 0f, 0f)
        android.opengl.Matrix.rotateM(m, 0, rot.z, 0f, 0f, 1f)
        val out = FloatArray(4)
        android.opengl.Matrix.multiplyMV(out, 0, m, 0, floatArrayOf(nx, ny, nz, 0f), 0)
        return out
    }
}
