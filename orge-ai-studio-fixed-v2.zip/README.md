# Forge AI Studio

AI-powered 3D game studio (3D viewport, scene explorer, Luau script assistant, Roblox asset export).

View your app in AI Studio: https://ai.studio/apps/9149b081-b003-462d-9afc-bedf86b588f6

> **यह एक native Android ऐप है (Kotlin + Jetpack Compose + OpenGL ES), वेब ऐप नहीं।**
> इसलिए AppMint जैसे "web-to-APK" टूल इसे नहीं बना सकते। वे `package.json` में `react`, `index.html` और
> Vite प्रोजेक्ट माँगते हैं, जो इस ऐप में नहीं है। इस ऐप का APK नीचे बताए तरीक़े से बनाइए।

## APK बनाना (PC की ज़रूरत नहीं, फ़ोन/टैबलेट के ब्राउज़र से)

### तरीक़ा A: सिर्फ़ 2 फ़ाइलें अपलोड करना (टैबलेट के लिए सबसे आसान)

1. github.com पर नया **repository** बनाइए (Public ठीक है; free GitHub Actions minutes मिलते हैं)।
2. Repo में **Add file → Create new file** दबाइए। नाम वाले बॉक्स में ठीक यह लिखिए:
   `.github/workflows/build-apk.yml`
   (स्लैश `/` लिखते ही फ़ोल्डर अपने-आप बन जाते हैं)। अलग से दी गई `build-apk.yml` फ़ाइल की पूरी लिखावट
   इसमें चिपकाइए और **Commit changes** दबाइए।
3. **Add file → Upload files** से यह पूरी **`.zip` फ़ाइल जैसी है वैसी ही** (बिना खोले) अपलोड कीजिए, फिर **Commit changes**।
4. **Actions → Build APK → Run workflow** दबाइए। 5 से 15 मिनट इंतज़ार कीजिए।
5. Run पूरा होने पर नीचे **Artifacts** में `forge-ai-studio-debug-apk` दिखेगा। उसे डाउनलोड करके unzip कीजिए,
   अंदर `app-debug.apk` होगी। उसे इंस्टॉल कीजिए (अनजान स्रोत से इंस्टॉल की अनुमति देनी पड़ सकती है)।

### तरीक़ा B: पूरा प्रोजेक्ट अपलोड करना

प्रोजेक्ट unzip करके सारी फ़ाइलें और फ़ोल्डर (`.github` फ़ोल्डर समेत) repo में अपलोड कीजिए, फिर ऊपर का स्टेप 4 और 5।
टैबलेट के फ़ाइल-पिकर से फ़ोल्डर चुनना अक्सर नहीं हो पाता, इसलिए तरीक़ा A बेहतर है।

### तरीक़ा C: Android Studio / कमांड लाइन

```
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

Android Studio में चलाने के लिए: प्रोजेक्ट फ़ोल्डर को **Open** कीजिए, Gradle sync होने दीजिए, फिर Run दबाइए।

## ज़रूरी बातें

- **Gemini API key की ज़रूरत नहीं है।** AI कॉल Firebase AI Logic + App Check से सर्वर साइड होते हैं।
  इसलिए ऐप में कहीं भी API key या `process.env` नहीं है।
- **Google Sign-In** तभी चलेगा जब `debug.keystore` का SHA-1 Firebase प्रोजेक्ट में जुड़ा हो
  (Project settings → Your apps → Add fingerprint)। SHA-1 निकालने के लिए:
  `keytool -list -v -keystore debug.keystore -storepass android`
- `debug.keystore` एक सामान्य Android debug key है। `app/build.gradle.kts` की `signingConfigs` को बदलिए मत,
  AI Studio में ऐप चलाने के लिए ये ज़रूरी हैं।
- `package.json`, `firestore.test.js`, `firebase.json` सिर्फ़ Firestore सुरक्षा-नियमों (`firestore.rules`) के
  टेस्ट के लिए हैं (`npm install && npm run test:rules`)। इनका ऐप के APK से कोई संबंध नहीं है।
- Release (Play Store) बिल्ड के लिए अपनी upload key चाहिए: `KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_PASSWORD` सेट कीजिए।
